package tk.tekporacademy.betweener.ui.customize;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.cardview.widget.CardView;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.util.Date;
import java.util.List;

import tk.tekporacademy.betweener.DatabaseAccess;
import tk.tekporacademy.betweener.R;
import tk.tekporacademy.betweener.ui.home.HomeClickedValue;

public class Customize extends AppCompatActivity {
    private AppCompatEditText quote;
    private CardView cardView;
    private TextView inspiration,gallery,solid,store,close,storeclose,save,image,status1,status2,status3,status4,toper,toper1,toper2;
    private ImageView left,right,bold, normal;
    private ImageView italic;
    private ImageView center;
    private ImageView white;
    private ImageView blue;
    private ImageView red;
    private ImageView black;
    private ImageView green;
    private ImageView yellow;
    private ImageView pink;
    private ImageView font1;
    private ImageView font2;
    private ImageView font3;
    private ImageView font4;
    private ImageView font5;
    private ImageView font6;
    private ImageView font7;
    private ImageView font8,font9,font10,font11,font12,font13,font14,font15,font16,font17,font18,font19,font20;
    private ImageView image1;
    private ImageView image2;
    private ImageView image3;
    private ImageView image4;
    private ImageView image5;
    private ImageView image6;
    private ImageView image7;
    private ImageView image8;
    private ImageView image9;
    private ImageView image10;
    private ImageView sizeMinus;
    private ImageView sizePlus;
    private ImageView backgroundImage;
    private LinearLayout photo,toperson,saveshow;
    private RelativeLayout relativeLayout,body;
    private RelativeLayout storerelativeLayout;
    private  int size = 22;
    private String status;
    private String audiance;
    byte[] picture = null;
    int pictureint = 0;
    private   String v;
    private  int SELECT_FILE =0;
    ScrollView scrollView;
    private RecyclerView recyclerView,storerecyclerView;
    private SolidAdapter solidAdapter;
    private StoreAdapter storeAdapter;
    private EditText by;
    private DatabaseReference databaseReference;
    private long max;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customize);
        try {
            relativeLayout= findViewById(R.id.solidview);
            body= findViewById(R.id.body);
            by= findViewById(R.id.by);
            storerelativeLayout= findViewById(R.id.storeview);
            quote = findViewById(R.id.quote);
            scrollView = findViewById(R.id.scrollTool);
            inspiration = findViewById(R.id.inspiration);
            store = findViewById(R.id.store);
            gallery = findViewById(R.id.gallery);
            solid = findViewById(R.id.solid);
            close = findViewById(R.id.close);
            storeclose = findViewById(R.id.storeclose);
            save = findViewById(R.id.save);
            cardView = findViewById(R.id.card);
            backgroundImage = findViewById(R.id.backgroundImage);
            font1 = findViewById(R.id.font1);
            font2 = findViewById(R.id.font2);
            font3 = findViewById(R.id.font3);
            font4 = findViewById(R.id.font4);
            font5 = findViewById(R.id.font5);
            font6 = findViewById(R.id.font6);
            font7 = findViewById(R.id.font7);
            font8 = findViewById(R.id.font8);
            font9 = findViewById(R.id.font9);
            font10 = findViewById(R.id.font10);
            font11 = findViewById(R.id.font11);
            font12 = findViewById(R.id.font12);
            font13 = findViewById(R.id.font13);
            font14 = findViewById(R.id.font14);
            font15 = findViewById(R.id.font15);
            font16 = findViewById(R.id.font16);
            font17 = findViewById(R.id.font17);
            font18 = findViewById(R.id.font18);
            font19 = findViewById(R.id.font19);
            font20 = findViewById(R.id.font20);
            blue = findViewById(R.id.blue);
            white = findViewById(R.id.white);
            black = findViewById(R.id.black);
            green = findViewById(R.id.green);
            yellow = findViewById(R.id.yellow);
            pink = findViewById(R.id.pink);
            red = findViewById(R.id.red);
            bold = findViewById(R.id.bold);
            normal = findViewById(R.id.normal);
            italic = findViewById(R.id.italic);
            left = findViewById(R.id.left);
            right = findViewById(R.id.right);
            image1 = findViewById(R.id.image1);
            image2 = findViewById(R.id.image2);
            image3 = findViewById(R.id.image3);
            image4 = findViewById(R.id.image4);
            image5 = findViewById(R.id.image5);
            image6 = findViewById(R.id.image6);
            image7 = findViewById(R.id.image7);
            image8 = findViewById(R.id.image8);
            image9 = findViewById(R.id.image9);
            image10 = findViewById(R.id.image10);
            center = findViewById(R.id.center);
            sizeMinus = findViewById(R.id.sizeminus);
            sizePlus = findViewById(R.id.sizeplus);
            image = findViewById(R.id.image);
            status1 = findViewById(R.id.status1);
            status2 = findViewById(R.id.status2);
            status3 = findViewById(R.id.status3);
            status4 = findViewById(R.id.status4);
            toper = findViewById(R.id.toper);
            toper1 = findViewById(R.id.toper1);
            toper2 = findViewById(R.id.toper2);
            photo = findViewById(R.id.photo);
            toperson = findViewById(R.id.toperson);
            saveshow = findViewById(R.id.saveshow);
            recyclerView = findViewById(R.id.solidimages);
            storerecyclerView = findViewById(R.id.storeimages);
            inspiration.setInputType(InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
            toper.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    audiance = toper.getText().toString();
                    toperson.setVisibility(View.GONE);
                    saved();
                }
            });
            toper1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    audiance = toper1.getText().toString();
                    toperson.setVisibility(View.GONE);
                    saved();
                }
            });
            toper2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    audiance = toper2.getText().toString();
                    toperson.setVisibility(View.GONE);
                    saved();
                }
            });




            status1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    status = status1.getText().toString();
                    saveshow.setVisibility(View.GONE);
                    toperson.setVisibility(View.VISIBLE);

                }
            });

            status2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    status = status2.getText().toString();
                    saveshow.setVisibility(View.GONE);
                    toperson.setVisibility(View.VISIBLE);
                }
            });


            status3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    status = status3.getText().toString();
                    saveshow.setVisibility(View.GONE);
                    toperson.setVisibility(View.VISIBLE);
                }
            });
            status4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    status = status4.getText().toString();
                    saveshow.setVisibility(View.GONE);
                    toperson.setVisibility(View.VISIBLE);
                }
            });



            setvalues();


            gallery.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    intent.setType("image/*");
                    startActivityForResult(Intent.createChooser(intent,"Select Image (Size < 3MB)"),SELECT_FILE);
                }
            });

            close.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    solidAdapter = null;
                    cardView.setVisibility(View.VISIBLE);
                    scrollView.setVisibility(View.VISIBLE);
                    relativeLayout.setVisibility(View.GONE);
                }
            });
            storeclose.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    storeAdapter = null;
                    cardView.setVisibility(View.VISIBLE);
                    scrollView.setVisibility(View.VISIBLE);
                    storerelativeLayout.setVisibility(View.GONE);
                }
            });
            solid.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    cardView.setVisibility(View.GONE);
                    scrollView.setVisibility(View.GONE);
                    solidAdapter = new SolidAdapter(Customize.this,null);
                    recyclerView.setLayoutManager(new GridLayoutManager(Customize.this, 3));
                    recyclerView.setAdapter(solidAdapter);
                    relativeLayout.setVisibility(View.VISIBLE);


                }
            });

            store.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    cardView.setVisibility(View.GONE);
                    scrollView.setVisibility(View.GONE);
                    storerelativeLayout.setVisibility(View.VISIBLE);
                    photo.setVisibility(View.GONE);
                    databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/Store");
                    databaseReference.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if(snapshot.exists())
                                max = (snapshot.getChildrenCount());
                            storeAdapter = new StoreAdapter(Customize.this,max);
                            storerecyclerView.setLayoutManager(new GridLayoutManager(Customize.this, 3));
                            storerecyclerView.setAdapter(storeAdapter);
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });


                }
            });




            body.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    saveshow.setVisibility(View.GONE);
                    toperson.setVisibility(View.GONE);
                    photo.setVisibility(View.GONE);
                }
            });


            save.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    DatabaseAccess databaseAccess = DatabaseAccess.getInstance(Customize.this);
                    databaseAccess.open();
                    List<String> uerName = databaseAccess.getUerName();
                    databaseAccess.close();
                    try {
                        if (uerName.get(0) != null){

                            by.setCursorVisible(false);
                            quote.setCursorVisible(false);
                            if (quote.getText().toString().length()>1){
                                setDrafth();
                                if (saveshow.getVisibility() ==View.GONE){
                                    saveshow.setVisibility(View.VISIBLE);
                                }else {
                                    saveshow.setVisibility(View.GONE);
                                }

                                if (toperson.getVisibility() ==View.GONE){
                                    toperson.setVisibility(View.VISIBLE);
                                }else {
                                    toperson.setVisibility(View.GONE);
                                }
                            }



                        }else {
                            Toast.makeText(Customize.this,"PLEASE SIGN UP",Toast.LENGTH_LONG).show();
                        }
                    }catch (IndexOutOfBoundsException e){
                        e.getStackTrace();
                        Toast.makeText(Customize.this,"PLEASE SIGN UP",Toast.LENGTH_LONG).show();
                    }




                }
            });


            image.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (photo.getVisibility() == View.GONE){
                        photo.setVisibility(View.VISIBLE);
                    }else {
                        photo.setVisibility(View.GONE);
                    }
                }
            });

            image1.setOnClickListener(new View.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.M)
                @Override
                public void onClick(View view) {
                    backgroundImage.setForeground(getResources().getDrawable(R.color.whitetrans));
                }
            });

            image2.setOnClickListener(new View.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.M)
                @Override
                public void onClick(View view) {
                    backgroundImage.setForeground(getResources().getDrawable(R.color.yellowtrans));
                }
            });
            image3.setOnClickListener(new View.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.M)
                @Override
                public void onClick(View view) {
                    backgroundImage.setForeground(getResources().getDrawable(R.color.bluetrans));
                }
            });
            image4.setOnClickListener(new View.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.M)
                @Override
                public void onClick(View view) {
                    backgroundImage.setForeground(getResources().getDrawable(R.color.redtrans));
                }
            });
            image5.setOnClickListener(new View.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.M)
                @Override
                public void onClick(View view) {
                    backgroundImage.setForeground(getResources().getDrawable(R.color.greentrans));
                }
            });
            image6.setOnClickListener(new View.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.M)
                @Override
                public void onClick(View view) {
                    backgroundImage.setForeground(getResources().getDrawable(R.color.browtrans));
                }
            });
            image7.setOnClickListener(new View.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.M)
                @Override
                public void onClick(View view) {
                    backgroundImage.setForeground(getResources().getDrawable(R.color.pinktrans));
                }
            });
            image8.setOnClickListener(new View.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.M)
                @Override
                public void onClick(View view) {
                    backgroundImage.setForeground(getResources().getDrawable(R.color.blacktrans));
                }
            });
            image9.setOnClickListener(new View.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.M)
                @Override
                public void onClick(View view) {
                    backgroundImage.setForeground(getResources().getDrawable(R.color.darkbluetrans));
                }
            });
            image10.setOnClickListener(new View.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.M)
                @Override
                public void onClick(View view) {
                    backgroundImage.setForeground(getResources().getDrawable(R.color.ligthbluetrans));
                }
            });

quote.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        saveshow.setVisibility(View.GONE);
        toperson.setVisibility(View.GONE);
        photo.setVisibility(View.GONE);
        by.setCursorVisible(true);
        quote.setCursorVisible(true);
    }
});
by.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        by.setCursorVisible(true);
        quote.setCursorVisible(true);
    }
});
            blue.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quote.setTextColor(getResources().getColor(R.color.blue));
                }
            });
            red.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quote.setTextColor(getResources().getColor(R.color.red));
                }
            });
            black.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quote.setTextColor(getResources().getColor(R.color.black));
                }
            });
            white.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quote.setTextColor(getResources().getColor(R.color.white));
                }
            });
            pink.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quote.setTextColor(getResources().getColor(R.color.pink));
                }
            });

            yellow.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quote.setTextColor(getResources().getColor(R.color.yellow));
                }
            });
            green.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quote.setTextColor(getResources().getColor(R.color.green));
                }
            });


            normal.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quote.setTypeface(null, Typeface.NORMAL);
                }
            });
            italic.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quote.setTypeface(null, Typeface.ITALIC);
                }
            });
            bold.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quote.setTypeface(null, Typeface.BOLD);
                }
            });
            sizeMinus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    size -=1;
                    quote.setTextSize(size);
                }
            });
            sizePlus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    size +=1;
                    quote.setTextSize(size);
                }
            });

            font1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quote.setTypeface(ResourcesCompat.getFont(Customize.this,R.font.otto));
                }
            });
            font2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quote.setTypeface(ResourcesCompat.getFont(Customize.this,R.font.ano));
                }
            });

            font3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quote.setTypeface(ResourcesCompat.getFont(Customize.this,R.font.jacob));
                }
            });

            font4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quote.setTypeface(ResourcesCompat.getFont(Customize.this,R.font.cute));
                }
            });
            font5.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quote.setTypeface(ResourcesCompat.getFont(Customize.this,R.font.stylus));
                }
            });

            font6.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quote.setTypeface(ResourcesCompat.getFont(Customize.this,R.font.course));
                }
            });


            font7.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quote.setTypeface(ResourcesCompat.getFont(Customize.this,R.font.precious));
                }
            });

            font8.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quote.setTypeface(ResourcesCompat.getFont(Customize.this,R.font.aladin_regular));
                }
            });

            font9.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quote.setTypeface(ResourcesCompat.getFont(Customize.this,R.font.aldrich_regular));
                }
            });


            font10.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quote.setTypeface(ResourcesCompat.getFont(Customize.this,R.font.aldrich_regular));
                }
            });


            font11.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quote.setTypeface(ResourcesCompat.getFont(Customize.this,R.font.allertastenciegular));
                }
            });


            font12.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quote.setTypeface(ResourcesCompat.getFont(Customize.this,R.font.annieuseyourtelescope_regular));
                }
            });

            font13.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quote.setTypeface(ResourcesCompat.getFont(Customize.this,R.font.reeniebeanie_regular));
                }
            });

            font14.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quote.setTypeface(ResourcesCompat.getFont(Customize.this,R.font.tekporlipos));
                }
            });

            font15.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quote.setTypeface(ResourcesCompat.getFont(Customize.this,R.font.italianno_egular));
                }
            });


            font16.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quote.setTypeface(ResourcesCompat.getFont(Customize.this,R.font.knewave_regular));
                }
            });

            font17.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quote.setTypeface(ResourcesCompat.getFont(Customize.this,R.font.kurale_regular));
                }
            });

            font18.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quote.setTypeface(ResourcesCompat.getFont(Customize.this,R.font.nerkoone_regular));
                }
            });

            font19.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quote.setTypeface(ResourcesCompat.getFont(Customize.this,R.font.pattaya_regular));
                }
            });

            font20.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    quote.setTypeface(ResourcesCompat.getFont(Customize.this,R.font.shrikhand_regular));
                }
            });
            inspiration.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                    try {
                        setDrafth();
                    }catch (OutOfMemoryError e){
                        final PackageManager pm = getPackageManager();
                        final Intent intent = pm.getLaunchIntentForPackage(getPackageName());
                        finishAffinity();
                        startActivity(intent);
                        System.exit(0);
                    }

                }
                @Override
                public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                }
                @Override
                public void afterTextChanged(Editable editable) {

                }
            });
        }catch (RuntimeException e){
          e.getStackTrace();
        }

    }

    private void setvalues() {
        DatabaseAccess databaseAccess = DatabaseAccess.getInstance(this);
        databaseAccess.open();
        List<String> draft = databaseAccess.getDraft();
        databaseAccess.close();
        databaseAccess.open();

        picture = databaseAccess.getPicture();
        databaseAccess.close();

        if (picture != null ){
            final BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            options.inSampleSize = 2;
            options.inJustDecodeBounds = false;
            options.inTempStorage = new byte[16 * 1024];

            Bitmap bitmap  = BitmapFactory.decodeByteArray(picture,0,picture.length);
            backgroundImage.setImageBitmap(bitmap);
            setImagees(null,bitmap,0,null);
        }else {
            databaseAccess.open();
            pictureint = databaseAccess.getPictureInt();
            databaseAccess.close();
            if (pictureint != 0){
                backgroundImage.setImageResource(pictureint);
                setImagees(null,null,pictureint,null);
            }else {
                databaseAccess.open();
                String pictureuri = databaseAccess.getPicturelink();
                databaseAccess.close();
                if (pictureuri != null){
                    Picasso.get().load(Uri.parse(pictureuri)).placeholder(R.drawable.text).into(backgroundImage);
                    setImagees(null,null,0,Uri.parse(pictureuri));
                }
            }
        }
        if (draft.size() > 0){
            if (draft.get(0) != ""){
                quote.setText(draft.get(0));
                quote.setText(quote.getText().toString());
            }
            if (draft.get(1) != ""){
                inspiration.setText(draft.get(1));
            }
        }

    }

    private void saved() {
        String username = "Anonymous";
        String userid = "0";
        Date date = new Date();
        v = date.toString().concat(String.valueOf(Math.random()));
        DatabaseAccess databaseAccess = DatabaseAccess.getInstance(this);
        databaseAccess.open();
        List<String> uerName = databaseAccess.getUerName();
        databaseAccess.close();
        databaseAccess.open();
        List<String> uerId = databaseAccess.getUerId();
        databaseAccess.close();

        if (uerName.size() > 0){
            username = uerName.get(0);
        }
        if (uerId.size() > 0){
            userid = uerId.get(0);
        }
        Bitmap b = getBitmap(cardView);
       databaseAccess.open();
        databaseAccess.setSave(v,username,b,inspiration.getText().toString(),userid,status,audiance,this);databaseAccess.close();
        Intent intent = new Intent(this, HomeClickedValue.class);
        intent.putExtra("postid",v);
        intent.putExtra("resource",1);
        intent.putExtra("username",username);
        intent.putExtra("place",1);
        intent.putExtra("inspiration",inspiration.getText().toString());
        databaseAccess.open();
        databaseAccess.clearDraft();
        databaseAccess.close();
        this.startActivity(intent);
    }

    private Bitmap getBitmap(View view){
        Bitmap bitmap =null;
        Canvas canvas = null;
        Drawable drawable = null;
        try {
            bitmap = Bitmap.createBitmap(view.getWidth(),view.getHeight(),Bitmap.Config.ARGB_8888);
            canvas = new Canvas(bitmap);
            drawable = view.getBackground();
        }catch (IllegalArgumentException e){
            e.getStackTrace();
        }

        if (drawable != null){
            drawable.draw(canvas);
        }else {
            try {
                canvas.drawColor(getResources().getColor(R.color.whitetrans));
            }catch (NullPointerException e){
                e.getStackTrace();
            }

        }

        try {
            view.draw(canvas);
        }catch (NullPointerException e){
            e.getStackTrace();
        }
        return bitmap;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            Uri uri = null;
            if (requestCode == SELECT_FILE){
                try {
                    uri = data.getData();
                    backgroundImage.setImageURI(uri);
                    photo.setVisibility(View.GONE);
                    setImagees(uri,null,0,null);
                    Bitmap bitmap = getBitmap(backgroundImage);
                    DatabaseAccess databaseAccess = DatabaseAccess.getInstance(this);
                    databaseAccess.open();
                    databaseAccess.updatePicture(bitmap,0,null);
                    databaseAccess.close();
                }catch (RuntimeException e){
                    e.getStackTrace();
                }
            }
        }catch (OutOfMemoryError e){
            final PackageManager pm = getPackageManager();
            final Intent intent = pm.getLaunchIntentForPackage(getPackageName());
            finishAffinity();
            startActivity(intent);
            System.exit(0);
        }

    }
    private void setImagees(Uri uri,Bitmap bitmap,int id,Uri url) {
        if (uri != null) {
            image1.setImageURI(uri);
            image2.setImageURI(uri);
            image3.setImageURI(uri);
            image4.setImageURI(uri);
            image5.setImageURI(uri);
            image6.setImageURI(uri);
            image7.setImageURI(uri);
            image8.setImageURI(uri);
            image9.setImageURI(uri);
            image10.setImageURI(uri);
        } else {
            if (bitmap != null) {
                image1.setImageBitmap(bitmap);
                image2.setImageBitmap(bitmap);
                image3.setImageBitmap(bitmap);
                image4.setImageBitmap(bitmap);
                image5.setImageBitmap(bitmap);
                image6.setImageBitmap(bitmap);
                image7.setImageBitmap(bitmap);
                image8.setImageBitmap(bitmap);
                image9.setImageBitmap(bitmap);
                image10.setImageBitmap(bitmap);

            } else {
                if (id != 0) {
                    image1.setImageResource(id);
                    image2.setImageResource(id);
                    image3.setImageResource(id);
                    image4.setImageResource(id);
                    image5.setImageResource(id);
                    image6.setImageResource(id);
                    image7.setImageResource(id);
                    image8.setImageResource(id);
                    image9.setImageResource(id);
                    image10.setImageResource(id);
                }else {
                    if (url != null){
                        Picasso.get().load(url).placeholder(R.drawable.text).into(image1);
                        Picasso.get().load(url).placeholder(R.drawable.text).into(image2);
                        Picasso.get().load(url).placeholder(R.drawable.text).into(image3);
                        Picasso.get().load(url).placeholder(R.drawable.text).into(image4);
                        Picasso.get().load(url).placeholder(R.drawable.text).into(image5);
                        Picasso.get().load(url).placeholder(R.drawable.text).into(image6);
                        Picasso.get().load(url).placeholder(R.drawable.text).into(image7);
                        Picasso.get().load(url).placeholder(R.drawable.text).into(image8);
                        Picasso.get().load(url).placeholder(R.drawable.text).into(image9);
                        Picasso.get().load(url).placeholder(R.drawable.text).into(image10);
                    }
                }
            }

        }
    }
    private void setDrafth(){
        DatabaseAccess databaseAccess = DatabaseAccess.getInstance(this);
        Bitmap bitmap =null;
        try {
            bitmap = getBitmap(backgroundImage);
        }catch (RuntimeException e){
            e.getStackTrace();
        }

        if (!quote.getText().toString().isEmpty()){
            databaseAccess.open();
            databaseAccess.setDraft(bitmap,quote.getText().toString(),inspiration.getText().toString());
            databaseAccess.close();
        }


    }

}