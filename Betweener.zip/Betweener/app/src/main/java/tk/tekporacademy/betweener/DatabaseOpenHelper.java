package tk.tekporacademy.betweener;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.readystatesoftware.sqliteasset.SQLiteAssetHelper;

public class DatabaseOpenHelper extends SQLiteAssetHelper {
    private static final String DATABASE_NAME = "saved.db";
    private static final int DATABASE_VERSION = 1;
    private Context context;

    public DatabaseOpenHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.needUpgrade(newVersion);
        db.execSQL("DROP TABLE  draft");
        db.execSQL("DROP TABLE  draftQuestion");
        db.execSQL("DROP TABLE  question");
        db.execSQL("DROP TABLE  save");
        db.execSQL("DROP TABLE  saveQuestion");
        db.execSQL("DROP TABLE  savedview");
        db.execSQL("DROP TABLE  savedviewQuestion");
        db.execSQL("DROP TABLE  tags");
        db.execSQL("DROP TABLE  user");

        new DatabaseOpenHelper(context);

    }
}