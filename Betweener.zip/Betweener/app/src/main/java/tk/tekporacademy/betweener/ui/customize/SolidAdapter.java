package tk.tekporacademy.betweener.ui.customize;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import tk.tekporacademy.betweener.DatabaseAccess;
import tk.tekporacademy.betweener.R;
import tk.tekporacademy.betweener.ui.me.AskQuestion;

public class SolidAdapter extends RecyclerView.Adapter<SolidAdapter.holder> {
    private  int[] colours = {R.color.black,R.color.orange,R.color.violet,R.color.blue,R.color.red,R.color.green,R.color.yellow,R.color.pink,R.color.white};

    public SolidAdapter(Context context, String activity) {
        this.context = context;
        this.activity = activity;
    }

    Context context;
    String activity;
    @NonNull
    @Override
    public holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.solid_recycle,parent,false);
        holder holder = new holder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull holder holder, int position) {
        holder.solidView.setAnimation(AnimationUtils.loadAnimation(context,R.anim.splash));
      holder.solidView.setImageResource(colours[position]);
   final int value = colours[position];
        holder.solidView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DatabaseAccess databaseAccess = DatabaseAccess.getInstance(context);
                databaseAccess.open();
                databaseAccess.updatePicture(null,value,null);
                databaseAccess.close();
if (activity == "Question"){
    Intent intent = new Intent(context,AskQuestion.class);
    context.startActivity(intent);
}else {
    Intent intent = new Intent(context,Customize.class);
    context.startActivity(intent);
}

            }
        });

    }

    @Override
    public int getItemCount() {
        return colours.length;
    }

    public class holder extends RecyclerView.ViewHolder {
        ImageView solidView;
        public holder(@NonNull View itemView) {
            super(itemView);
            solidView = itemView.findViewById(R.id.solidView);
        }
    }
}
