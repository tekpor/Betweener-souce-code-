package tk.tekporacademy.betweener.ui.customize;

import androidx.lifecycle.ViewModel;

public class CustomizeViewModel extends ViewModel {


}