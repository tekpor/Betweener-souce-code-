package tk.tekporacademy.betweener;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.net.Uri;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import tk.tekporacademy.betweener.objects.Store;

public class DatabaseAccess {
    private SQLiteOpenHelper openHelper;
    private SQLiteDatabase database;
    private static DatabaseAccess instance;
    private   String col_1 = "id";
    private   String col_2 = "picture";
    private   String col_3 = "quote";
    private   String col_4 = "inspiration";
    private   String col_5 = "url";
    private   String col_6 = "userId";
    private   String col_7 = "status";
    private   String col_8 = "people";
    private   String col_9 = "main";
    private   String col_10 = "name";
    private   String col_11 = "postid";
    private  DatabaseReference databaseReference;
    private StorageReference mStorageRef;
    private long max = 0;
    private long maxed = 0;
    /**
     * Private constructor to aboid object creation from outside classes.
     *
     * @param context
     */
    private DatabaseAccess(Context context) {
        this.openHelper = new DatabaseOpenHelper(context);
    }

    /**
     * Return a singleton instance of DatabaseAccess.
     *
     * @param context the Context
     * @return the instance of DabaseAccess
     */
    public static DatabaseAccess getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseAccess(context);
        }
        return instance;
    }

    /**
     * Open the database connection.
     */
    public void open() {
        this.database = openHelper.getWritableDatabase();
    }

    /**
     * Close the database connection.
     */
    public void close() {
        if (database != null) {
            this.database.close();
        }
    }

    /**
     * Read all quotes from the database.
     *
     * @return a List of quotes
     */

    public  void setDraft(Bitmap picture, String quote, String inspiration) {
        ContentValues contentValues = new ContentValues();
        byte[] bytes = null;
        if (picture ==  null){
            try {
                ByteArrayOutputStream byteArrayInputStream = new ByteArrayOutputStream();
                picture.compress(Bitmap.CompressFormat.PNG,100,byteArrayInputStream);
                bytes = byteArrayInputStream.toByteArray();
            }catch (NullPointerException e){
                e.getStackTrace();
            }

        }
        Cursor cursor = database.rawQuery("SELECT * FROM draft WHERE id = 1", null);
        if (!cursor.moveToFirst()){
            contentValues.put(col_1, 1);
            contentValues.put(col_2,bytes);
            contentValues.put(col_3, quote);
            contentValues.put(col_4, inspiration);
            database.insert("draft", null, contentValues);
        }else {

            contentValues.put(col_1, 1);
            contentValues.put(col_2,bytes);
            contentValues.put(col_3, quote);
            contentValues.put(col_4, inspiration);
            database.update("draft", contentValues, "id = 1",null );
        }

    }

    public  void setSave(String postid, final String name, Bitmap quote, final String inspiration, String v, String status, final String people, final Context context) {
        ByteArrayOutputStream byteArrayInputStream = new ByteArrayOutputStream();
        quote.compress(Bitmap.CompressFormat.PNG,100,byteArrayInputStream);
        byte[] bytes = byteArrayInputStream.toByteArray();

        Date date = new Date();
        final String handler = date.toString().concat(String.valueOf(Math.random()));
        databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/Save/"+status);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists())
                    max = (snapshot.getChildrenCount());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        mStorageRef = FirebaseStorage.getInstance().getReference();
        StorageReference mountainImagesRef = mStorageRef.child("images/"+handler.replace(" ","_")+".png");
        UploadTask uploadTask = mountainImagesRef.putBytes(bytes);
        uploadTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                Toast.makeText(context,"IMAGE UPLOAD FAILED TRY AGAIN",Toast.LENGTH_LONG).show();
            }
        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                Toast.makeText(context,"IMAGE UPLOADED",Toast.LENGTH_LONG).show();
                databaseReference.child(String.valueOf(max+1)).child("audiance").setValue(people);
                databaseReference.child(String.valueOf(max+1)).child("handler").setValue(handler);
                databaseReference.child(String.valueOf(max+1)).child("inspiration").setValue(inspiration);
                databaseReference.child(String.valueOf(max+1)).child("like").setValue("0");
                databaseReference.child(String.valueOf(max+1)).child("share").setValue("0");
                databaseReference.child(String.valueOf(max+1)).child("name").setValue(name);
                databaseReference.child(String.valueOf(max+1)).child("save").setValue("0");
                databaseReference.child(String.valueOf(max+1)).child("view").setValue("0");

            }
        });

        ContentValues contentValues = new ContentValues();
        contentValues.put(col_10,name);
        contentValues.put(col_6,v);
        contentValues.put(col_4, inspiration);
        contentValues.put(col_9, bytes);
        contentValues.put(col_7,"");
        contentValues.put(col_8,"");
        contentValues.put(col_11,postid);
        database.insert("save", null, contentValues);



    }

    public  void setStore(final Context context) {

        DatabaseAccess databaseAccess = DatabaseAccess.getInstance(context);
        databaseAccess.open();
        List<String> saved = databaseAccess.getStore();

        databaseAccess.close();

        for (int i =0; i < saved.size() ;  i++) {
            databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/Store");
            databaseReference.child(String.valueOf(i)).setValue(new Store(saved.get(i)));
            Toast.makeText(context,saved.get(i).concat(String.valueOf(i)),Toast.LENGTH_SHORT).show();
        }



    }




    public  void setSaveed(String postid, String name, Bitmap quote, String inspiration) {
        ByteArrayOutputStream byteArrayInputStream = new ByteArrayOutputStream();
        quote.compress(Bitmap.CompressFormat.PNG,100,byteArrayInputStream);
        byte[] bytes = byteArrayInputStream.toByteArray();
        ContentValues contentValues = new ContentValues();
        contentValues.put(col_10,name);
        contentValues.put(col_6,"");
        contentValues.put(col_4, inspiration);
        contentValues.put(col_9, bytes);
        contentValues.put(col_7,"");
        contentValues.put(col_8,"");
        contentValues.put(col_11,postid);
        database.insert("save", null, contentValues);

    }


    public List<String> getStore() {
        List<String> list = new ArrayList<>();
        String quarry = "SELECT * FROM Store WHERE 1";
        Cursor cursor = database.rawQuery(quarry, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            list.add(cursor.getString(0));
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }


    public List<String> getDraft() {
        List<String> list = new ArrayList<>();
        String quarry = "SELECT * FROM draft WHERE id = 1";
        Cursor cursor = database.rawQuery(quarry, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            list.add(cursor.getString(2));
            list.add(cursor.getString(3));
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }

    public List<String> getSave(String s) {
        List<String> list = new ArrayList<>();
        String quarry = "SELECT * FROM save WHERE postid = \""+s+"\"";
        Cursor cursor = database.rawQuery(quarry, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            list.add(cursor.getString(1));
            list.add(cursor.getString(3));
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }
    public List<String> getSaved() {
        List<String> list = new ArrayList<>();
        String quarry = "SELECT * FROM save WHERE 1";
        Cursor cursor = database.rawQuery(quarry, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            list.add(cursor.getString(1));
            list.add(cursor.getString(3));
            list.add(cursor.getString(7));
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }
    public List<byte[]> getSavedBlob() {
        List<byte[]> list = new ArrayList<>();
        String quarry = "SELECT * FROM save WHERE  1";
        Cursor cursor = database.rawQuery(quarry, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            list.add(cursor.getBlob(4));

            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }

    //get view
    public List<String> getview() {
        List<String> list = new ArrayList<>();
        String quarry = "SELECT * FROM savedview WHERE  id = 1";
        Cursor cursor = database.rawQuery(quarry, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            list.add(cursor.getString(1));
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }

// set view
    public  void setsavedview(Uri quote) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("picture", quote.toString());
        database.update("savedview", contentValues, "id = 1",null );

    }

    public List<byte[]> getaSavedBlob(String s) {
        List<byte[]> list = new ArrayList<>();
        String quarry = "SELECT * FROM save WHERE  postid = \""+s+"\"";
        Cursor cursor = database.rawQuery(quarry, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            list.add(cursor.getBlob(4));

            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }
    public byte[] getQuote(String s) {
        byte[] blob = null;
        String quarry = "SELECT * FROM save WHERE postid = \""+s+"\"";
        Cursor cursor = database.rawQuery(quarry, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            blob = cursor.getBlob(4);
            cursor.moveToNext();
        }
        cursor.close();
        return blob;
    }

    public void clearDraft() {
        int url = R.drawable.text;
        ContentValues contentValues = new ContentValues();
        contentValues.put(col_1, 1);
        contentValues.put(col_2,"");
        contentValues.put(col_3, "");
        contentValues.put(col_4, "");
        contentValues.put(col_5, url);
        database.update("draft", contentValues, "id = 1",null );
    }




    public void restriction(boolean s) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("restriction",s);
        database.update("user", contentValues, "id = 1",null );
    }

    public String getrestriction() {
        String list = null;
        String quarry = "SELECT * FROM user WHERE id = 1";
        Cursor cursor = database.rawQuery(quarry, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            list =  cursor.getString(8);
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }

    public void notification(String s) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("notification",s);
        database.update("user", contentValues, "id = 1",null );
    }
    public String getnotification(String s) {
       String list = null;
        String quarry = "SELECT * FROM user WHERE id = 1";
        Cursor cursor = database.rawQuery(quarry, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            list =  cursor.getString(7);
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }
    /**
     * @return
     */
    public byte[] getPicture() {
        byte[] list = null;
        String quarry = "SELECT * FROM draft WHERE id = 1";
        Cursor cursor = database.rawQuery(quarry, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            list =  cursor.getBlob(1);
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }
    public int getPictureInt() {
        int list = 0;
        String quarry = "SELECT * FROM draft WHERE id = 1";
        Cursor cursor = database.rawQuery(quarry, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            list =  cursor.getInt(4);
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }
    public String getPicturelink() {
        String list = null;
        String quarry = "SELECT * FROM draft WHERE id = 1";
        Cursor cursor = database.rawQuery(quarry, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            list =  cursor.getString(5);
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }

    public  void updatePicture(Bitmap picture, int res, String uri) {
        ContentValues contentValues = new ContentValues();
        byte[] bytes = null;
        if (picture != null){
            ByteArrayOutputStream byteArrayInputStream = new ByteArrayOutputStream();
            picture.compress(Bitmap.CompressFormat.PNG,100,byteArrayInputStream);
            bytes = byteArrayInputStream.toByteArray();
            contentValues.put(col_2,bytes);
            contentValues.put(col_5,"0");
            database.update("draft", contentValues, "id = 1",null );
        }else {
            if (res != 0){
                String quarry = "UPDATE draft SET  picture = null, url = "+res+"  WHERE id = 1";
                database.execSQL(quarry);
            }else {
                if (uri != null){
                    String quarry = "UPDATE draft SET  picture = null,url = 0, link = \""+uri+"\"  WHERE id = 1";
                    database.execSQL(quarry);
                }
            }
        }

    }

    public void setCode(String code) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("code", code);
        database.update("user", contentValues, "id = 1",null );
    }

    public String getCode() {
        String list = null;
        String quarry = "SELECT * FROM user WHERE 1";
        Cursor cursor = database.rawQuery(quarry, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            list = cursor.getString(3);
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }
    public String getconfirm() {
        String list = null;
        String quarry = "SELECT * FROM user WHERE 1";
        Cursor cursor = database.rawQuery(quarry, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            list = cursor.getString(5);
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }
    public List<String> getUerName() {
        List<String> list = new ArrayList<>();
        String quarry = "SELECT * FROM user WHERE 1";
        Cursor cursor = database.rawQuery(quarry, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            list.add(cursor.getString(1));
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }
    public List<String> getUerId() {
        List<String> list = new ArrayList<>();
        String quarry = "SELECT * FROM user WHERE 1";
        Cursor cursor = database.rawQuery(quarry, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            list.add(cursor.getString(8));
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }
    public List<byte[]> getUserBlob() {
        List<byte[]> list = new ArrayList<>();
        String quarry = "SELECT * FROM user WHERE 1";
        Cursor cursor = database.rawQuery(quarry, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            list.add(cursor.getBlob(6));
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }

    public String getHandler() {
        String list = null;
        String quarry = "SELECT * FROM user WHERE 1";
        Cursor cursor = database.rawQuery(quarry, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
        list = cursor.getString(1);
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }



    public void createAccount(String name, String email, String code, String userid, final Context context) {
        ContentValues contentValues = new ContentValues();
            contentValues.put(col_1, 1);
            contentValues.put("name",name);
            contentValues.put("email", email);
            contentValues.put("confirm", code);
            contentValues.put("userid", userid);

        database.insert("user", null, contentValues);
        databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/User/"+name);
        databaseReference.child("name").setValue(name);
        databaseReference.child("email").setValue(email);
        databaseReference.child("code").setValue(code);
        Toast.makeText(context,"ACCOUNT CREATED",Toast.LENGTH_LONG).show();


    }

    public void getLocation(String country,String state) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("country",country);
        contentValues.put("timezone",state);
        database.insert("location", null, contentValues);
    }


    public void setProfile(Bitmap set,final Context context) {
        ContentValues contentValues = new ContentValues();
        byte[] bytes = null;
        if (set != null){
            ByteArrayOutputStream byteArrayInputStream = new ByteArrayOutputStream();
            set.compress(Bitmap.CompressFormat.PNG,100,byteArrayInputStream);
            bytes = byteArrayInputStream.toByteArray();
            contentValues.put("profile",bytes);
            database.update("user", contentValues, "id = 1",null );

            mStorageRef = FirebaseStorage.getInstance().getReference();
            StorageReference mountainImagesRef = mStorageRef.child("profile/"+getHandler()+".png");
            UploadTask uploadTask = mountainImagesRef.putBytes(bytes);
            uploadTask.addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception exception) {
                    Toast.makeText(context,"IMAGE UPLOAD LOAD FAILED TRY AGAIN",Toast.LENGTH_LONG).show();
                }
            }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    Toast.makeText(context,"IMAGE UPLOAD LOADED",Toast.LENGTH_LONG).show();

                }
            });


        }
    }


    public List<String> getDraftQuestion() {
        List<String> list = new ArrayList<>();
        String quarry = "SELECT * FROM draftQuestion WHERE id = 1";
        Cursor cursor = database.rawQuery(quarry, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            list.add(cursor.getString(2));
            list.add(cursor.getString(3));
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }


    public int getPictureIntQuestion() {
        int list = 0;
        String quarry = "SELECT * FROM draftQuestion WHERE id = 1";
        Cursor cursor = database.rawQuery(quarry, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            list =  cursor.getInt(4);
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }
    public String getPicturelinkQuestion() {
        String list = null;
        String quarry = "SELECT * FROM draftQuestion WHERE id = 1";
        Cursor cursor = database.rawQuery(quarry, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            list =  cursor.getString(5);
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }

    public void signout() {
        String list = null;
        String quarry = "DELETE FROM user WHERE id = 1";
    database.execSQL(quarry);
    }

    public  void setSaveQuestion(final  String v, final String name, Bitmap quote, final String inspiration, final String status, final String people, final Context context) {
        ByteArrayOutputStream byteArrayInputStream = new ByteArrayOutputStream();
        quote.compress(Bitmap.CompressFormat.PNG,100,byteArrayInputStream);
        byte[] bytes = byteArrayInputStream.toByteArray();

        Date date = new Date();
        final String handler = date.toString().concat(String.valueOf(Math.random()));
        databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/Question");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists())
                    max = (snapshot.getChildrenCount());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        mStorageRef = FirebaseStorage.getInstance().getReference();
        StorageReference mountainImagesRef = mStorageRef.child("question/"+handler.replace(" ","_").replace("+","_").replace(".","_")+".png");
        UploadTask uploadTask = mountainImagesRef.putBytes(bytes);
        uploadTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                Toast.makeText(context,"IMAGE UPLOAD FAILED TRY AGAIN",Toast.LENGTH_LONG).show();
            }
        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                databaseReference.child(String.valueOf(max+1)).child("username").setValue(name);
                databaseReference.child(String.valueOf(max+1)).child("title").setValue(inspiration);
                databaseReference.child(String.valueOf(max+1)).child("handler").setValue(handler.replace(" ","_").replace("+","_").replace(".","_"));
                databaseReference.child(String.valueOf(max+1)).child("people").setValue(people);
                databaseReference.child(String.valueOf(max+1)).child("status").setValue(status);
                databaseReference.child(String.valueOf(max+1)).child("comments").setValue(0);
                databaseReference.child(String.valueOf(max+1)).child("view").setValue(0);
                databaseReference.child(String.valueOf(max+1)).child("tag").setValue(0);
                Toast.makeText(context,"IMAGE UPLOADED",Toast.LENGTH_LONG).show();
            }
        });

        ContentValues contentValues = new ContentValues();
        contentValues.put(col_10,name);
        contentValues.put(col_4, inspiration);
        contentValues.put(col_9, bytes);
        contentValues.put(col_7,"");
        contentValues.put(col_8,"");
        contentValues.put(col_11,v);
        try {
            database.insert("saveQuestion", null, contentValues);
        }catch (SQLiteConstraintException e){
          Toast.makeText(context,"Already Exist",Toast.LENGTH_LONG).show();
        }




    }


    public  void setDraftQuestion(Bitmap picture, String quote, String inspiration) {
        ContentValues contentValues = new ContentValues();
        byte[] bytes = null;
        if (picture ==  null){
            ByteArrayOutputStream byteArrayInputStream = new ByteArrayOutputStream();
            picture.compress(Bitmap.CompressFormat.PNG,100,byteArrayInputStream);
            bytes = byteArrayInputStream.toByteArray();
        }
        Cursor cursor = database.rawQuery("SELECT * FROM draft WHERE id = 1", null);
        if (!cursor.moveToFirst()){
            contentValues.put(col_1, 1);
            contentValues.put(col_2,bytes);
            contentValues.put(col_3, quote);
            contentValues.put(col_4, inspiration);
            database.insert("draftQuestion", null, contentValues);
        }else {

            contentValues.put(col_1, 1);
            contentValues.put(col_2,bytes);
            contentValues.put(col_3, quote);
            contentValues.put(col_4, inspiration);
            database.update("draftQuestion", contentValues, "id = 1",null );
        }

    }
    public void clearDraftQuestion() {
        ContentValues contentValues = new ContentValues();
        contentValues.put(col_1, 1);
        contentValues.put(col_2,"");
        contentValues.put(col_3, "");
        contentValues.put(col_4, "");
        contentValues.put(col_5, "");
        database.update("draftQuestion", contentValues, "id = 1",null );
    }
    public byte[] getPictureQuestion() {
        byte[] list = null;
        String quarry = "SELECT * FROM draftQuestion WHERE id = 1";
        Cursor cursor = database.rawQuery(quarry, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            list =  cursor.getBlob(1);
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }
    public List<byte[]> getaSavedBlobQuestion(String s) {
        List<byte[]> list = new ArrayList<>();
        String quarry = "SELECT * FROM saveQuestion WHERE  postid = \""+s+"\"";
        Cursor cursor = database.rawQuery(quarry, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            list.add(cursor.getBlob(4));
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }


    public List<Integer> tags() {
        List<Integer> list = new ArrayList<>();
        String quarry = "SELECT * FROM tags WHERE 1";
        Cursor cursor = database.rawQuery(quarry, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            list.add(cursor.getInt(1));
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }


    public  void setTages(String postid, String name) {

        ContentValues contentValues = new ContentValues();
        contentValues.put("tagid",postid);
        contentValues.put("time",name);
        database.insert("tags", null, contentValues);
    }

    public List<String> getSavedQuestion() {
        List<String> list = new ArrayList<>();
        String quarry = "SELECT * FROM saveQuestion WHERE 1";
        Cursor cursor = database.rawQuery(quarry, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            list.add(cursor.getString(7));
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }
    public List<byte[]> getSavedBlobQuestion() {
        List<byte[]> list = new ArrayList<>();
        String quarry = "SELECT * FROM saveQuestion WHERE  1";
        Cursor cursor = database.rawQuery(quarry, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            list.add(cursor.getBlob(4));

            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }




    public void setComment(String message, String name, String postid, Context context) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("message",message);
        contentValues.put("userid", name);
        contentValues.put("postid", postid);

        database.insert("comment", null, contentValues);



        if (new MainActivity().isNetworkAvailable(context)){
if (!postid.isEmpty()){
    databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/comment/"+postid);
    databaseReference.addValueEventListener(new ValueEventListener() {
        @Override
        public void onDataChange(@NonNull DataSnapshot snapshot) {
            if(snapshot.exists())
                maxed = (snapshot.getChildrenCount());
        }

        @Override
        public void onCancelled(@NonNull DatabaseError error) {

        }
    });
    databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/comment/"+postid);
    databaseReference.child(String.valueOf(maxed+1)).child("message").setValue(message);
    databaseReference.child(String.valueOf(maxed+1)).child("username").setValue(name);
}

        }
    }





    public List<String> getComment(String postid) {
        List<String> list = new ArrayList<>();
        String quarry = "SELECT * FROM comment WHERE postid = \""+postid+"\"";
        Cursor cursor = database.rawQuery(quarry, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            list.add(cursor.getString(1));
            list.add(cursor.getString(2));
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }
}