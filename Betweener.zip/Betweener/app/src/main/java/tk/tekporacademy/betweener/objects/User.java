package tk.tekporacademy.betweener.objects;

public class User {
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    String name;
    String email;
    String userid;
    String code;

    public User(String name, String email, String userid, String code) {
        this.name = name;
        this.email = email;
        this.userid = userid;
        this.code = code;
    }



}