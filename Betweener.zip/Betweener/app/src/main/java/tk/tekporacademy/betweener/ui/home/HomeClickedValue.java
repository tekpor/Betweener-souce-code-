package tk.tekporacademy.betweener.ui.home;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.drawee.view.SimpleDraweeView;
import com.facebook.imagepipeline.core.ImagePipelineConfig;
import com.facebook.imagepipeline.core.ImageTranscoderType;
import com.facebook.imagepipeline.core.MemoryChunkType;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import tk.tekporacademy.betweener.DatabaseAccess;
import tk.tekporacademy.betweener.R;
import tk.tekporacademy.betweener.ui.customize.Customize;

public class HomeClickedValue extends AppCompatActivity {
    private SimpleDraweeView qimage;
    private TextView share;
    private TextView save;
    private TextView like;
    private TextView profile;
    private TextView inspiration;
    private String postid = "null";
    private String username = "null";
    private String insp = "null";
    private int blob;
    private int rec;
    String viewed;
    String shared;
    String saveed = null;
    String liked;
    String time = "0";
    CircleImageView  profile_image;
    private Bitmap bitmap;
    private DatabaseReference databaseReference;
    private StorageReference mStorageRef;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        Fresco.initialize(
                this,
                ImagePipelineConfig.newBuilder(this)
                        .setMemoryChunkType(MemoryChunkType.BUFFER_MEMORY)
                        .setImageTranscoderType(ImageTranscoderType.JAVA_TRANSCODER)
                        .experiment().setNativeCodeDisabled(true)
                        .build());


        setContentView(R.layout.activity_home_clicked_value);
        final Intent intent = getIntent();
        postid = intent.getStringExtra("postid");
        username = intent.getStringExtra("username");
        insp = intent.getStringExtra("inspiration");
        time = intent.getStringExtra("time");
        viewed = intent.getStringExtra("view");
         shared = intent.getStringExtra("share");
         liked = intent.getStringExtra("like");
         saveed = intent.getStringExtra("save");
        blob = intent.getIntExtra("resource",0);
        rec = intent.getIntExtra("place",0);
        qimage = findViewById(R.id.qimage);
        save = findViewById(R.id.save);
        profile_image = findViewById(R.id.profile_image);
        profile = findViewById(R.id.profile);
        share = findViewById(R.id.share);
        inspiration = findViewById(R.id.inspiration);
        like = findViewById(R.id.like);
like.setText(liked);
share.setText(shared);
save.setText(saveed);


        if (postid != null){
            if (blob ==1){
                DatabaseAccess databaseAccess = DatabaseAccess.getInstance(this);
                databaseAccess.open();
                final List<byte[]> savedBlob = databaseAccess.getaSavedBlob(postid);
                databaseAccess.close();
                bitmap  = BitmapFactory.decodeByteArray(savedBlob.get(0),0,savedBlob.get(0).length);
                qimage.setImageBitmap(bitmap);

            }else {
                if (blob ==2 ){
                    DatabaseAccess databaseAccess = DatabaseAccess.getInstance(this);
                    databaseAccess.open();
                    final List<String> getview = databaseAccess.getview();
                    databaseAccess.close();
                        qimage.setImageURI(Uri.parse(getview.get(0)));

                }else{
                    qimage.setImageResource(R.drawable.text);
                }

            }
            if (username.length() > 5){
                profile.setText(username.toUpperCase());
            }else {
                profile.setText("BETWEENER");
            }
            if (insp.length() > 5){
                inspiration.setText(insp);
            }else {
                inspiration.setText("");
            }
        }

        mStorageRef = FirebaseStorage.getInstance().getReference();
        mStorageRef.child("profile/"+username+".png").getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                if (uri!=null){
                    Picasso.get().load(uri).placeholder(R.drawable.ic_baseline_perm_identity_24).into(profile_image);
                }
            }
        });

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseAccess databaseAccess = DatabaseAccess.getInstance(HomeClickedValue.this);
                databaseAccess.open();
                databaseAccess.setSaveed(postid,profile.getText().toString(),getBitmap(qimage),inspiration.getText().toString());
                databaseAccess.close();
                Toast.makeText(HomeClickedValue.this,"Saved",Toast.LENGTH_LONG).show();
            }
        });


        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(HomeClickedValue.this,ProfileView.class);
                intent1.putExtra("name",profile.getText().toString());
                startActivity(intent1);
            }
        });



        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/Save/"+time);
                databaseReference.child(String.valueOf(postid)).child("share").setValue(Integer.parseInt(shared)+1);
                share(qimage,inspiration.getText().toString());
            }
        });
    }
    public void share(View view, String text) {
        Bitmap b = getBitmap(view);
        String filename = Math.random()+"betweener.png";
        try {
            File file = new File(HomeClickedValue.this.getExternalCacheDir(),filename);
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            b.compress(Bitmap.CompressFormat.PNG,100,fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
            file.setReadable(true,false);
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(file));
            intent.putExtra(Intent.EXTRA_TEXT, text+"\n \n\n https://play.google.com/store/apps/details?id=tk.tekporacademy.betweener");
            intent.setType("*/*");
            startActivity(Intent.createChooser(intent,"Share via"));

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private Bitmap getBitmap(View view){
        Bitmap bitmap = Bitmap.createBitmap(view.getWidth(),view.getHeight(),Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Drawable drawable = view.getBackground();
        if (drawable != null){
            drawable.draw(canvas);
        }else {
            canvas.drawColor(getResources().getColor(R.color.whitetrans));
        }
        view.draw(canvas);
        return bitmap;
    }

    @Override
    public void onBackPressed() {

        if (rec == 1){
            Intent intent = new Intent(HomeClickedValue.this, Customize.class);
            startActivity(intent);
            finish();
        }else {
            super.onBackPressed();
            finish();
        }
    }

}