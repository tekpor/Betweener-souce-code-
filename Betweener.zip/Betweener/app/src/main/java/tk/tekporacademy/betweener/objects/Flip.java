package tk.tekporacademy.betweener.objects;

public class Flip {

    public String getFlip() {
        return flip;
    }

    public void setFlip(String flip) {
        this.flip = flip;
    }

    private String flip;
}
