package tk.tekporacademy.betweener.ui.home;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;
import android.widget.ViewFlipper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.imagepipeline.core.ImagePipelineConfig;
import com.facebook.imagepipeline.core.ImageTranscoderType;
import com.facebook.imagepipeline.core.MemoryChunkType;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import pl.droidsonroids.gif.GifImageView;
import tk.tekporacademy.betweener.DatabaseAccess;
import tk.tekporacademy.betweener.MainActivity;
import tk.tekporacademy.betweener.R;


public class HomeFragment extends Fragment {
    private  RecyclerView recyclerView;
    private RelativeLayout relativeLayout;
    private HomeViewModel homeViewModel;
    private ViewFlipper viewFlipper;
    private  DatabaseReference databaseReference;
    private long max;
    private long current = 0;
    private long getCurrent = 40;
    private GifImageView loading;
    private String feeling;
    private ImageView more;
    private  int luckynumber;
    private String audance;


    int[] gallery_grid_Images = {R.drawable.flip1, R.drawable.flip2, R.drawable.flip3, R.drawable.flip4, R.drawable.flip5};
    public View onCreateView(@NonNull final LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        viewFlipper = root.findViewById(R.id.viewFlipper);
        relativeLayout = root.findViewById(R.id.homeClick);
        loading = root.findViewById(R.id.loading);
        more = root.findViewById(R.id.more);
        recyclerView = root.findViewById(R.id.recycle);
        more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (max< pageNumber()){
                    more.setVisibility(View.GONE);
                }else {
                    current +=10;
                    homeViewModel.setMaxed(pageNumber());

                    Random randNum = new Random();
                    Set<Integer> list = new LinkedHashSet<Integer>();
List<Integer> set = new ArrayList<>();
                    while (list.size() < (int) pageNumber()) {
                        list.add(randNum.nextInt((int) pageNumber())+1);
                    }
                    set.addAll(list);
                    homeViewModel.setSet(set);
                    recyclerView.clearOnChildAttachStateChangeListeners();
                    homeViewModel.notifyDataSetChanged();
                }
            }
        });




if (new MainActivity().isNetworkAvailable(getContext())){


    databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/FlipView");
    databaseReference.addValueEventListener(new ValueEventListener() {
        @Override
        public void onDataChange(@NonNull DataSnapshot snapshot) {
            List<String> gallery_grid_Images = new ArrayList<>();
            try {
                gallery_grid_Images.add(snapshot.child("flip1").getValue().toString());
                gallery_grid_Images.add(snapshot.child("flip2").getValue().toString());
                gallery_grid_Images.add(snapshot.child("flip3").getValue().toString());
                gallery_grid_Images.add(snapshot.child("flip4").getValue().toString());
                gallery_grid_Images.add(snapshot.child("flip5").getValue().toString());
                gallery_grid_Images.add(snapshot.child("flip6").getValue().toString());
                gallery_grid_Images.add(snapshot.child("flip7").getValue().toString());
                gallery_grid_Images.add(snapshot.child("flip8").getValue().toString());
                gallery_grid_Images.add(snapshot.child("flip9").getValue().toString());
                gallery_grid_Images.add(snapshot.child("flip10").getValue().toString());

                int unto = (int) Math.round(Math.random()*9);

                    setFlipperImage(gallery_grid_Images.get(unto));


            }catch (NullPointerException e){
                e.getStackTrace();
            }




        }

        @Override
        public void onCancelled(@NonNull DatabaseError error) {

        }
    });

}else {
    for(int i=0; i<gallery_grid_Images.length; i++){
        setFlipperImage(gallery_grid_Images[i]);

    }
}



        if (!new MainActivity().isNetworkAvailable(getContext())){
            Toast.makeText(getContext(),"YOU ARE OFFLINE SHOWING SAVED DATA",Toast.LENGTH_LONG).show();
            DatabaseAccess databaseAccess = DatabaseAccess.getInstance(getContext());
            databaseAccess.open();
            List<String> saved = databaseAccess.getSaved();
            databaseAccess.close();
            databaseAccess.open();
            List<byte[]> blob = databaseAccess.getSavedBlob();
            databaseAccess.close();
            if (saved.isEmpty()){
                Toast.makeText(getContext(),"SORRY NO DATA AVAILABLE",Toast.LENGTH_LONG).show();
            }else {
                homeViewModel = new HomeViewModel(getContext(),saved,blob,0,0,null);
                LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
                recyclerView.setLayoutManager(linearLayoutManager);
                recyclerView.setAnimation(AnimationUtils.loadAnimation(getActivity(),R.anim.splash));

                recyclerView.setAdapter(homeViewModel);
                loading.setVisibility(View.GONE);

            }

        }






        return root;
    }

    private void setFlipperImage(int res) {
        try {
            ImageView image = new ImageView(getContext());
            image.setScaleType(ImageView.ScaleType.FIT_XY);
            image.setImageResource(res);
            viewFlipper.addView(image);
            viewFlipper.setFlipInterval(7000);
            viewFlipper.setAutoStart(true);
        }catch (OutOfMemoryError e){
            e.getStackTrace();
        }

    }

    private void setFlipperImage(String res) {
        try {
            ImageView image = new ImageView(getContext());
            image.setScaleType(ImageView.ScaleType.FIT_XY);
            Picasso.get().load(Uri.parse(res)).into(image);
            viewFlipper.addView(image);
            viewFlipper.setFlipInterval(7000);
            viewFlipper.setAutoStart(true);
        } catch (OutOfMemoryError e) {
            e.getStackTrace();
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
         luckynumber = (int) Math.round((Math.random()*2)+1);
        Fresco.initialize(
                getContext(),
                ImagePipelineConfig.newBuilder(getContext())
                        .setMemoryChunkType(MemoryChunkType.BUFFER_MEMORY)
                        .setImageTranscoderType(ImageTranscoderType.JAVA_TRANSCODER)
                        .experiment().setNativeCodeDisabled(true)
                        .build());




        if (new MainActivity().isNetworkAvailable(getContext())){
            Calendar c = Calendar.getInstance();
            int timeOfDay = c.get(Calendar.HOUR_OF_DAY);

            if (timeOfDay >= 0 && timeOfDay < 9) {
                feeling = "Morning";


                switch (luckynumber){
                    case 1:
                        audance = "Family";
                        break;
                    case 2:
                        audance = "Partner";
                        break;
                    case 3:
                        audance = "Friends";
                        break;
                }


            } else if (timeOfDay >= 9 && timeOfDay < 16) {
                feeling = "Afternoon";


                switch (luckynumber){
                    case 1:
                        audance = "Family";
                        break;
                    case 2:
                        audance = "Partner";
                        break;
                    case 3:
                        audance = "Friends";
                        break;
                }
            } else if (timeOfDay >= 16 && timeOfDay < 24) {
                feeling = "Evening";


                switch (luckynumber){
                    case 1:
                        audance = "Family";
                        break;
                    case 2:
                        audance = "Partner";
                        break;
                    case 3:
                        audance = "Friends";
                        break;
                }
            }
            databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/Save/"+feeling);
            databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    try {
                        if(snapshot.exists())
                            max = (snapshot.getChildrenCount());
                        homeViewModel = new HomeViewModel(getContext(),null,null,pageNumber(),max,audance);
                      try {
                          if (max < 1){
                              Toast.makeText(getContext(),"SORRY NO DATA AVAILABLE",Toast.LENGTH_LONG).show();
                          }
                      }catch (NullPointerException e){
                          e.getStackTrace();
                      }
                        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(requireContext());
                        recyclerView.setHasFixedSize(true);
                        recyclerView.setLayoutManager(linearLayoutManager);
                        recyclerView.setAdapter(homeViewModel);
                        loading.setVisibility(View.GONE);
                        if (getCurrent > max){
                            more.setVisibility(View.GONE);
                        }else {
                            more.setVisibility(View.VISIBLE);
                        }
                    }catch (IllegalStateException e){
                        e.getStackTrace();
                    }

                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }
    }

    private int pageNumber(){
        if (getCurrent > max){
            more.setVisibility(View.GONE);
            return (int) max;
        }else {
            more.setVisibility(View.VISIBLE);
           if (getCurrent+current > max){
               if (getCurrent+current < max+5){
                   more.setVisibility(View.GONE);
                   return (int) max;
               }else {
                 return (int) (getCurrent+current-3);
               }
           }else {
               return (int) (getCurrent+current);
           }
        }


    }


}