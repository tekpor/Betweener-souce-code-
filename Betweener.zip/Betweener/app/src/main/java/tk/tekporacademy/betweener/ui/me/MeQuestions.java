package tk.tekporacademy.betweener.ui.me;

import android.os.Bundle;
import android.view.animation.AnimationUtils;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;
import java.util.List;

import tk.tekporacademy.betweener.DatabaseAccess;
import tk.tekporacademy.betweener.MainActivity;
import tk.tekporacademy.betweener.R;
import tk.tekporacademy.betweener.ui.forum.ForumViewModel;
import tk.tekporacademy.betweener.ui.home.HomeViewModel;

public class MeQuestions extends AppCompatActivity {
    RecyclerView recyclerView;
    LinearLayoutManager linearLayoutManager;
    private DatabaseReference databaseReference;
    private long max;
    private String feeling;
    private String audance;
    private String askedby;
    private int luckynumber;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_me_questions);
        recyclerView = findViewById(R.id.recycle);
        luckynumber = (int) Math.round((Math.random()*2)+1);

        DatabaseAccess databaseAccess = DatabaseAccess.getInstance(this);
        databaseAccess.open();
        List<String> uerName = databaseAccess.getUerName();
        databaseAccess.close();

        if (uerName != null){
            try {
                askedby = uerName.get(0);
            }catch (IndexOutOfBoundsException e){
                e.getStackTrace();
            }

        }


        if (new MainActivity().isNetworkAvailable(this)){
            Toast.makeText(this,"LOADING...",Toast.LENGTH_LONG).show();
            Calendar c = Calendar.getInstance();
            int timeOfDay = c.get(Calendar.HOUR_OF_DAY);


            if (timeOfDay >= 6 && timeOfDay < 12) {
                feeling = "General";


                switch (luckynumber){
                    case 1:
                        audance = "Married";
                        break;
                    case 2:
                        audance = "Single";
                        break;
                    case 3:
                        audance = "General";
                        break;
                }


            } else if (timeOfDay >= 12 && timeOfDay < 20) {
                feeling = "Stress";


                switch (luckynumber){
                    case 1:
                        audance = "Married";
                        break;
                    case 2:
                        audance = "Single";
                        break;
                    case 3:
                        audance = "General";
                        break;
                }
            } else if (timeOfDay >= 20 && timeOfDay < 24) {
                feeling = "Love";


                switch (luckynumber){
                    case 1:
                        audance = "Married";
                        break;
                    case 2:
                        audance = "Single";
                        break;
                    case 3:
                        audance = "General";
                        break;
                }
            }else {
                feeling = "Love";


                switch (luckynumber){
                    case 1:
                        audance = "Married";
                        break;
                    case 2:
                        audance = "Single";
                        break;
                    case 3:
                        audance = "General";
                        break;
                }
            }
            databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/Question");
            databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    try {
                        if(snapshot.exists())
                            max = (snapshot.getChildrenCount());
                        ForumViewModel   forumViewModel = new ForumViewModel(MeQuestions.this,audance,feeling,max,null,null,askedby,null);
                        if (max < 1){
                            Toast.makeText(MeQuestions.this,"SORRY NO DATA AVAILABLE",Toast.LENGTH_LONG).show();
                        }
                        try {
                            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(MeQuestions.this);
                            recyclerView.setLayoutManager(linearLayoutManager);
                            recyclerView.setAdapter(forumViewModel);
                        }catch (IllegalStateException e){
                            e.getStackTrace();
                        }

                    }catch (NullPointerException e){
                        e.getStackTrace();
                    }

                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });

        }
    }
}