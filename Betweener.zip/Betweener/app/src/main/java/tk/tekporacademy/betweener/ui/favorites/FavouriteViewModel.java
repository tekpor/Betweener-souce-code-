package tk.tekporacademy.betweener.ui.favorites;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.view.InflateException;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;

import com.facebook.drawee.view.SimpleDraweeView;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import tk.tekporacademy.betweener.DatabaseAccess;
import tk.tekporacademy.betweener.R;
import tk.tekporacademy.betweener.ui.home.HomeClickedValue;

public class FavouriteViewModel extends Adapter<FavouriteViewModel.AddHoldder> {

    private DatabaseReference databaseReference;
    private Context context;
    private int increment = 0;

    public int getNuvisible() {
        return nuvisible;
    }

    private int nuvisible = 0;

    public long getMaxed() {
        return maxed;
    }

    public void setMaxed(long maxed) {
        this.maxed = maxed;
    }

    private long maxed;
    private String audiance;
    private static  Set<Integer>list = new LinkedHashSet<Integer>();

    public void setSet(List<Integer> set) {
        FavouriteViewModel.set = null;
        FavouriteViewModel.set = set;
    }

    private static  List<Integer>set = new ArrayList<>();
    String feeling = "Fun";

    public FavouriteViewModel(Context context, List<String> data, List<byte[]> blob, long maxed, String feel) {
        this.context = context;
        this.data = data;
        this.blob = blob;
        this.maxed = maxed;
        this.audiance = feel;
    }
    private List<String> data;
    private List<byte[]> blob;
    int number;
    private StorageReference mStorageRef;

    @NonNull
    @Override
    public FavouriteViewModel.AddHoldder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        FavouriteViewModel.AddHoldder holder = null;
        try {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.home_recycle,parent,false);
            holder = new FavouriteViewModel.AddHoldder(view);

        }catch (InflateException e){
            e.getStackTrace();
        }
        return holder;

    }
    @Override
    public void onBindViewHolder(@NonNull final FavouriteViewModel.AddHoldder holder, final int position) {
        holder.cardView.setAnimation(AnimationUtils.loadAnimation(context,R.anim.splash));

        if (data == null){

            if (position == 0){
                rundom();
            };
            databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/Save/Fun");
            databaseReference.child(String.valueOf(set.get(position))).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull final DataSnapshot snapshot) {
                    try {

                        if (snapshot.child("audiance").getValue().toString().equals(audiance)){
                            holder.container.setVisibility(View.VISIBLE);
                            nuvisible +=1;
                        }

                    }catch (NullPointerException e){
                        e.getStackTrace();
                    }

                    try {


                        final String  handler = snapshot.child("handler").getValue().toString();
                        holder.inspiration.setText(snapshot.child("inspiration").getValue().toString());
                        holder.name.setText(snapshot.child("name").getValue().toString());
                        holder.postid.setText(snapshot.getKey());
                        holder.share.setText(convert(snapshot.child("view").getValue().toString()));
                        holder.save.setText(convert(snapshot.child("save").getValue().toString()));
                        holder.like.setText(convert(snapshot.child("like").getValue().toString()));


                        mStorageRef = FirebaseStorage.getInstance().getReference();
                        mStorageRef.child("images/"+handler.replace(" ","_")+".png").getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                            @Override
                            public void onSuccess(final Uri uri) {


                                holder.qimage.setImageURI(uri);

                                holder.cardView.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        DatabaseAccess databaseAccess = DatabaseAccess.getInstance(context);
                                        databaseAccess.open();
                                        databaseAccess.setsavedview(uri);
                                        databaseAccess.close();

                                        databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/Save/"+feeling);
                                        databaseReference.child(String.valueOf(set.get(position))).child("view").setValue(Integer.parseInt(snapshot.child("view").getValue().toString())+1);


                                        Intent intent = new Intent(context,HomeClickedValue.class);
                                        intent.putExtra("postid",holder.postid.getText().toString());
                                        intent.putExtra("resource",2);
                                        intent.putExtra("time",feeling);
                                        intent.putExtra("share",snapshot.child("share").getValue().toString());
                                        intent.putExtra("like",snapshot.child("like").getValue().toString());
                                        intent.putExtra("save",snapshot.child("save").getValue().toString());
                                        intent.putExtra("username",holder.name.getText().toString());
                                        intent.putExtra("inspiration",holder.inspiration.getText().toString());
                                        context.startActivity(intent);
                                    }
                                });


                                holder.save.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        try {

                                            databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/Save/"+feeling);
                                            databaseReference.child(String.valueOf(set.get(position))).child("save").setValue(Integer.parseInt(snapshot.child("view").getValue().toString())+1);

                                            DatabaseAccess databaseAccess = DatabaseAccess.getInstance(context);
                                            databaseAccess.open();
                                            databaseAccess.setSaveed(holder.postid.getText().toString(),holder.name.getText().toString(),getBitmap(holder.qimage),holder.inspiration.getText().toString());
                                            databaseAccess.close();
                                            Toast.makeText(context,"Saved",Toast.LENGTH_LONG).show();
                                        }catch (Exception e){
                                            Toast.makeText(context,e.getMessage(),Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                });


                                holder.like.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        DatabaseAccess databaseAccess = DatabaseAccess.getInstance(context);
                                        databaseAccess.open();
                                        List<String> uerName = databaseAccess.getUerName();
                                        databaseAccess.close();
                                        try {
                                            if (uerName.get(0)!=null){
                                                databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/Save/"+feeling);
                                                databaseReference.child(String.valueOf(set.get(position))).child("like").setValue(Integer.parseInt(snapshot.child("like").getValue().toString())+1);
                                            }else {
                                                Toast.makeText(context,"PLEASE SIGN UP",Toast.LENGTH_LONG).show();
                                            }
                                        }catch (IndexOutOfBoundsException e){
                                            e.getStackTrace();
                                        }


                                    }
                                });

                                holder.share.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {


                                        DatabaseAccess databaseAccess = DatabaseAccess.getInstance(context);
                                        databaseAccess.open();
                                        String getrestriction = databaseAccess.getrestriction();
                                        databaseAccess.close();

                                        if (getrestriction != null){

                                            if (snapshot.child("audiance").getValue().toString() == "Partner"){
                                                if (getrestriction.equals("false")){

                                                    databaseAccess.open();
                                                    databaseAccess.setsavedview(uri);
                                                    databaseAccess.close();

                                                    databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/Save/"+feeling);
                                                    databaseReference.child(String.valueOf(set.get(position))).child("view").setValue(Integer.parseInt(snapshot.child("view").getValue().toString())+1);
                                                    Intent intent = new Intent(context,HomeClickedValue.class);
                                                    intent.putExtra("postid",holder.postid.getText().toString());
                                                    intent.putExtra("resource",2);
                                                    intent.putExtra("time",feeling);
                                                    intent.putExtra("view",snapshot.child("view").getValue().toString());
                                                    intent.putExtra("share",snapshot.child("share").getValue().toString());
                                                    intent.putExtra("like",snapshot.child("like").getValue().toString());
                                                    intent.putExtra("save",snapshot.child("save").getValue().toString());
                                                    intent.putExtra("username",holder.name.getText().toString());
                                                    intent.putExtra("inspiration",holder.inspiration.getText().toString());
                                                    context.startActivity(intent);

                                                }else {
                                                    Toast.makeText(context,"You are in RESTRICTION MODE. Change that in 'ME'.",Toast.LENGTH_LONG).show();
                                                }
                                            }else {
                                                databaseAccess.open();
                                                databaseAccess.setsavedview(uri);
                                                databaseAccess.close();

                                                databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/Save/"+feeling);
                                                databaseReference.child(String.valueOf(set.get(position))).child("view").setValue(Integer.parseInt(snapshot.child("view").getValue().toString())+1);
                                                Intent intent = new Intent(context,HomeClickedValue.class);
                                                intent.putExtra("postid",holder.postid.getText().toString());
                                                intent.putExtra("resource",2);
                                                intent.putExtra("time",feeling);
                                                intent.putExtra("view",snapshot.child("view").getValue().toString());
                                                intent.putExtra("share",snapshot.child("share").getValue().toString());
                                                intent.putExtra("like",snapshot.child("like").getValue().toString());
                                                intent.putExtra("save",snapshot.child("save").getValue().toString());
                                                intent.putExtra("username",holder.name.getText().toString());
                                                intent.putExtra("inspiration",holder.inspiration.getText().toString());
                                                context.startActivity(intent);
                                            }


                                        }else {
                                            Toast.makeText(context,"You are in RESTRICTION MODE. Change that in 'ME'.",Toast.LENGTH_LONG).show();
                                        }

                                    }
                                });


                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception exception) {
                                // Handle any errors
                            }
                        });

 }catch (NullPointerException e){
                        e.getStackTrace();
                    }


                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });

        }
    }

    @Override
    public int getItemCount() {
    return     SetItemCount(0);
    }

    public class AddHoldder extends RecyclerView.ViewHolder {
        CardView cardView;
        TextView share;
        TextView save;
        TextView name,postid;
        TextView like,inspiration;
        SimpleDraweeView qimage;
        LinearLayout container;

        public AddHoldder(@NonNull View itemView) {
            super(itemView);
            container = itemView.findViewById(R.id.container);
            cardView = itemView.findViewById(R.id.card);
            share = itemView.findViewById(R.id.share);
            save = itemView.findViewById(R.id.save);
            like = itemView.findViewById(R.id.like);
            qimage = itemView.findViewById(R.id.qimage);
            inspiration = itemView.findViewById(R.id.inspiration);
            name = itemView.findViewById(R.id.name);
            postid = itemView.findViewById(R.id.postid);
        }
    }


    private Bitmap getBitmap(View view){
        Bitmap bitmap = Bitmap.createBitmap(view.getWidth(),view.getHeight(),Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Drawable drawable = view.getBackground();
        if (drawable != null){
            drawable.draw(canvas);
        }else {
            canvas.drawColor(context.getResources().getColor(R.color.whitetrans));
        }
        view.draw(canvas);
        return bitmap;
    }

    public  String convert(String s){
        Integer maxedcommentl = 0;
        float maxedcomment = 0;
        String coml = "0";

        maxedcommentl = Integer.parseInt(s)+1;

        coml = String.valueOf(maxedcommentl);
        if (maxedcommentl >= 1000 && maxedcommentl < 1000000){
            maxedcommentl =   maxedcommentl/1000;

            coml = String.valueOf(Math.round(maxedcomment)).concat("K");
        }else if (maxedcommentl >= 1000000 ){
            maxedcommentl =   maxedcommentl/1000000;
            coml = String.valueOf(Math.round(maxedcommentl)).concat("M");
        }
        return coml;
    }



    public  void rundom(){
        Random randNum = new Random();

        while (list.size() < (int) maxed) {
            list.add(randNum.nextInt((int) maxed)+1);
        }
set.addAll(list);
    }
    public  int SetItemCount(int value){
        if (value != 0){
            return number;
        }else {
            if (blob == null){
                number = (int) maxed;
            }else {
                number = blob.size();
            }
            return number;
        }


    }

}