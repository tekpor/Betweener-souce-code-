package tk.tekporacademy.betweener.ui.forum;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import tk.tekporacademy.betweener.DatabaseAccess;
import tk.tekporacademy.betweener.MainActivity;
import tk.tekporacademy.betweener.R;
import tk.tekporacademy.betweener.ui.customize.Customize;
import tk.tekporacademy.betweener.ui.home.HomeViewModel;
import tk.tekporacademy.betweener.ui.home.ProfileView;
import tk.tekporacademy.betweener.ui.me.AskQuestion;

public class ForumComments extends AppCompatActivity {
    private SimpleDraweeView qimage;
    private TextView share;
    private TextView comments;
    private TextView like;
    private TextView profile;
    private TextView inspiration,tag;
    private String postid = "null";
    private String username = "null";
    private String insp = "null";
    private int blob;
    private Button send;
    private RecyclerView replyComment;
    private int place;
   private String com;
    private String uri;
    Integer maxedcommentl = 0;
    String coml = "0";
    private byte[] rec;
    long maxed = 0;
    long maxedcomment = 0;
    private TextInputEditText edit_query;
    private Bitmap bitmap;

    CircleImageView profile_image;
    String number;
    String likes;
    String taged;
    private DatabaseReference databaseReference;
    private StorageReference mStorageRef;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forum_comments);
        final Intent intent = getIntent();
        postid = intent.getStringExtra("postid");
        likes = intent.getStringExtra("like");
        taged = intent.getStringExtra("tag");
        username = intent.getStringExtra("username");
        uri = intent.getStringExtra("uri");
        insp = intent.getStringExtra("inspiration");
        place = intent.getIntExtra("place",0);
        blob = intent.getIntExtra("resource",0);

        qimage = findViewById(R.id.fqimage);
        comments = findViewById(R.id.comments);
        tag = findViewById(R.id.tag);
        profile_image = findViewById(R.id.profile_image);
        profile = findViewById(R.id.profile);
        edit_query = findViewById(R.id.edit_query);
        replyComment = findViewById(R.id.replyComment);
        share = findViewById(R.id.share);
        send = findViewById(R.id.send);
        inspiration = findViewById(R.id.inspiration);
        like = findViewById(R.id.like);
        profile.setText(username);
like.setText(likes);
tag.setText(taged);
if (!like.getText().toString().isEmpty()){
    maxedcommentl = Integer.parseInt(like.getText().toString())+1;
}
coml = String.valueOf(maxedcommentl);
        if (maxedcommentl >= 1000 && maxedcommentl < 1000000){
            maxedcommentl =   maxedcommentl/1000;
            coml = String.valueOf(Math.round(maxedcomment)).concat("K");
        }else if (maxedcommentl >= 1000000 ){
            maxedcommentl =   maxedcommentl/1000000;
            coml = String.valueOf(Math.round(maxedcommentl)).concat("M");
        }
        if (postid != null){
            if (postid.length() < 11){
                databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/Question/"+postid);
                databaseReference.child("view").setValue(coml);
            }
        }



        mStorageRef = FirebaseStorage.getInstance().getReference();
        mStorageRef.child("profile/"+username+".png").getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                if (uri!=null){
                    Picasso.get().load(uri).placeholder(R.drawable.ic_baseline_perm_identity_24).into(profile_image);
                }
            }
        });




setvaluesComent();



tag.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        if (postid != null){
            DatabaseAccess databaseAccess = DatabaseAccess.getInstance(ForumComments.this);
            databaseAccess.open();
            databaseAccess.setTages(postid,username);
            databaseAccess.close();
            if (postid != null){
                databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/Question"+postid);
                databaseReference.child("tag").setValue(Integer.parseInt(taged)+1);
            }

            Toast.makeText(ForumComments.this,"Tagged",Toast.LENGTH_LONG).show();
        }
    }
});


        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendValue(edit_query.getText().toString(),null,postid);
                setvaluesComent();
                edit_query.setText("");
            }
        });

        if (postid != null){




            if (blob ==1){
                DatabaseAccess databaseAccess = DatabaseAccess.getInstance(this);
                databaseAccess.open();
                final List<byte[]> savedBlob = databaseAccess.getaSavedBlobQuestion(postid);
                databaseAccess.close();
                try {
                    bitmap  = BitmapFactory.decodeByteArray(savedBlob.get(0),0,savedBlob.get(0).length);
                    qimage.setImageBitmap(bitmap);
                }catch (IndexOutOfBoundsException e){
                    e.getStackTrace();
                }


            }else {
                if (blob ==2 ){
                   qimage.setImageURI(Uri.parse(uri));
                }else{
                    qimage.setImageResource(R.drawable.text);
                }

            }
        }

    }

    private void setvaluesComent() {
        if (!new MainActivity().isNetworkAvailable(this)) {
            DatabaseAccess databaseAccess = DatabaseAccess.getInstance(this);
            databaseAccess.open();
            final List<String> getComment = databaseAccess.getComment(postid);
            databaseAccess.close();

            ForumCommentViewModel forumCommentViewModel = new ForumCommentViewModel(getComment,0,postid,this);
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
            replyComment.setLayoutManager(linearLayoutManager);
            replyComment.setAdapter(forumCommentViewModel);

        }else {
            if (postid != null){
                databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/comment/"+postid.replace(" ","_").replace("+","_").replace(".","_"));
                databaseReference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        if(snapshot.exists())
                            maxed = (snapshot.getChildrenCount());
                        maxedcomment = maxed;
                        com = String.valueOf(maxed);
                        if (maxedcomment >= 1000 && maxedcomment < 1000000){
                            maxedcomment =   maxedcomment/1000;
                            com = String.valueOf(Math.round(maxedcomment)).concat("K");
                        }else if (maxedcomment >= 1000000 ){
                            maxedcomment =   maxedcomment/1000000;
                            com = String.valueOf(Math.round(maxedcomment)).concat("M");
                        }
                        number =com;
                        comments.setText(com);
                        if (postid.length() < 11){
                            databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/Question/"+postid);
                            databaseReference.child("comments").setValue(com);
                        }
                        ForumCommentViewModel forumCommentViewModel = new ForumCommentViewModel(null,maxed,postid,ForumComments.this);
                        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(ForumComments.this);
                        replyComment.setLayoutManager(linearLayoutManager);
                        replyComment.setAdapter(forumCommentViewModel);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }






        }
    }

    private void sendValue(String mess, String username, String postid) {
        DatabaseAccess databaseAccess = DatabaseAccess.getInstance(this);
        databaseAccess.open();
        List<String> uerName = databaseAccess.getUerName();
        databaseAccess.close();

        if (uerName != null){
            try {
                username = uerName.get(0);
            }catch (IndexOutOfBoundsException e){
                e.getStackTrace();
                Toast.makeText(this,"Please Sign Up",Toast.LENGTH_LONG).show();
            }
            if (postid != null && mess.length() > 5 && !username.isEmpty()){
                databaseAccess.open();
                databaseAccess.setComment(mess,username,postid,this);
                databaseAccess.close();
            }else {
                Toast.makeText(this,"Something Went Wrong(Answer too Short)",Toast.LENGTH_LONG).show();
            }

        }else {
            Toast.makeText(this,"Please Sign Up",Toast.LENGTH_LONG).show();
        }

    }

    @Override
    public void onBackPressed() {
        if (place != 0){
            Intent i = new Intent(ForumComments.this, AskQuestion.class);
            startActivity(i);
            finish();
        }else {
            super.onBackPressed();
        }


    }

}