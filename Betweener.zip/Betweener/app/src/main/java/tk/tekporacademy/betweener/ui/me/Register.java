package tk.tekporacademy.betweener.ui.me;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Date;

import tk.tekporacademy.betweener.DatabaseAccess;
import tk.tekporacademy.betweener.R;

public class Register extends AppCompatActivity {
    private Button register,signin;
    private EditText username, email,virificationcode;
    private TextView textinput_error,policy,resend,readpolicy;
    private DatabaseReference databaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        register = findViewById(R.id.register);
        signin = findViewById(R.id.signin);
        username = findViewById(R.id.userName);
        readpolicy = findViewById(R.id.readpolicy);
        email = findViewById(R.id.email);
        virificationcode = findViewById(R.id.virificationcode);
        textinput_error = findViewById(R.id.textinput_error);
        policy = findViewById(R.id.policy);
        resend = findViewById(R.id.resend);

        resend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Register.this,"Code sent",Toast.LENGTH_LONG).show();
            }
        });

        readpolicy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Register.this,Policy.class);
                startActivity(intent);
            }
        });

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/User/"+username.getText().toString());
                databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if(dataSnapshot.exists()){
                            if (dataSnapshot.child("name").getValue().toString().equals(username.getText().toString())){
                                if (dataSnapshot.child("code").getValue().toString().equals(virificationcode.getText().toString())){
                                    DatabaseAccess databaseAccess = DatabaseAccess.getInstance(Register.this);
                                    databaseAccess.open();
                                    databaseAccess.createAccount(username.getText().toString(),dataSnapshot.child("email").getValue().toString(),dataSnapshot.child("code").getValue().toString(),null,Register.this);
                                    databaseAccess.close();
                                    finish();
                                }else {
                                    Toast.makeText(Register.this,"Wrong Code",Toast.LENGTH_LONG).show();
                                }
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        });


        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (username.getText().toString().length() > 5 && username.getText().toString().length() < 16 && username.getText().toString().indexOf(" ") == -1){

                    if (isValid(email.getText().toString())){
                        double random = Math.random()*10000;
                        String coded = String.valueOf(Math.round(random));
                        String codenew = null;
                         if (coded.length() != 4){
                             if (coded.length() > 4){
                                 codenew =    coded.substring(0,3);
                             }else  if (coded.length() < 4){
                                 codenew =    coded.concat("00000").substring(0,3);
                             }
                         }else {
                             codenew  = coded;
                         }
                      final   String code = codenew;
                        Date date = new Date();
                        final String v = date.toString().concat(String.valueOf(Math.random()));
                        final DatabaseAccess databaseAccess = DatabaseAccess.getInstance(Register.this);

                        databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/User/"+username.getText().toString());
                        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                if(dataSnapshot.exists()){
                                    textinput_error.setText("USERNAME ALREADY EXIST");
                                    textinput_error.setVisibility(View.VISIBLE);
                                    register.setVisibility(View.GONE);
                                    signin.setVisibility(View.VISIBLE);
                                    resend.setVisibility(View.VISIBLE);
                                    email.setVisibility(View.GONE);
                                    policy.setVisibility(View.GONE);
                                    virificationcode.setVisibility(View.VISIBLE);
                                }else {
                                    databaseAccess.open();
                                    databaseAccess.createAccount(username.getText().toString(),email.getText().toString(),code,v,Register.this);
                                    databaseAccess.close();
                                    finish();
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });







                    }else {
                        textinput_error.setVisibility(View.VISIBLE);
                        textinput_error.setText("WRONG EMAIL");
                    }
                }else {
                    textinput_error.setVisibility(View.VISIBLE);
                    textinput_error.setText("USER NAME TOO SHORT, TOO LONG OR CONTAINS WHITE SPACE");
                }


            }
        });

    }

    static boolean isValid(String emailed) {
        String regex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
        return emailed.matches(regex);
    }

}