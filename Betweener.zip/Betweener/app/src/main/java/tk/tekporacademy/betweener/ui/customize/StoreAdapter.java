package tk.tekporacademy.betweener.ui.customize;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import tk.tekporacademy.betweener.DatabaseAccess;
import tk.tekporacademy.betweener.R;

public class StoreAdapter extends RecyclerView.Adapter<StoreAdapter.holder> {



    public StoreAdapter(Context context, long size) {
        this.context = context;
        this.size = size;
    }

    Context context;
    long size;
    private DatabaseReference databaseReference;
    @NonNull
    @Override
    public holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        holder holder = null;
        try {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.store_recycle,parent,false);
             holder = new holder(view);

        }catch (OutOfMemoryError e){

        }

        return holder;

    }

    @Override
    public void onBindViewHolder(@NonNull final holder holder, final int position) {
        try {
            holder.storeView.setAnimation(AnimationUtils.loadAnimation(context,R.anim.splash));
        }catch (OutOfMemoryError e){
            e.getStackTrace();
        }

        databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/Store");
        databaseReference.child(String.valueOf(position)).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                try {
                    Picasso.get().load(Uri.parse(snapshot.child("link").getValue().toString())).placeholder(R.drawable.text).into(holder.storeView);
                    final String link = snapshot.child("link").getValue().toString();
                    holder.storeView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            DatabaseAccess databaseAccess = DatabaseAccess.getInstance(context);
                            databaseAccess.open();
                            databaseAccess.updatePicture(null,0,link);
                            databaseAccess.close();

                            Intent intent = new Intent(context,Customize.class);
                            context.startActivity(intent);
                        }
                    });
                }catch (NullPointerException e){
                    e.getStackTrace();
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    @Override
    public int getItemCount() {
        return (int) size;
    }

    public class holder extends RecyclerView.ViewHolder {
        ImageView storeView;
        public holder(@NonNull View itemView) {
            super(itemView);
            storeView = itemView.findViewById(R.id.storeView);
        }
    }
    private Bitmap getBitmap(View view){
        Bitmap bitmap = Bitmap.createBitmap(view.getWidth(),view.getHeight(),Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Drawable drawable = view.getBackground();
        if (drawable != null){
            drawable.draw(canvas);
        }else {
            canvas.drawColor(context.getResources().getColor(R.color.whitetrans));
        }
        view.draw(canvas);
        return bitmap;
    }
}
