package tk.tekporacademy.betweener.ui.me;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import tk.tekporacademy.betweener.DatabaseAccess;
import tk.tekporacademy.betweener.R;
import tk.tekporacademy.betweener.ui.home.HomeViewModel;

public class MeSave extends AppCompatActivity {
    private RecyclerView recyclerView;
    private HomeViewModel homeViewModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_me_save);
        recyclerView = findViewById(R.id.recycle);

        DatabaseAccess databaseAccess = DatabaseAccess.getInstance(this);
        databaseAccess.open();
        List<String> saved = databaseAccess.getSaved();
        databaseAccess.close();
        databaseAccess.open();
        databaseAccess.open();
        List<byte[]> blob = databaseAccess.getSavedBlob();
        databaseAccess.close();
        databaseAccess.open();
        homeViewModel = new HomeViewModel(this,saved,blob,0,0,null);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(homeViewModel);
    }
}