package tk.tekporacademy.betweener.ui.forum;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.imagepipeline.core.ImagePipelineConfig;
import com.facebook.imagepipeline.core.ImageTranscoderType;
import com.facebook.imagepipeline.core.MemoryChunkType;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;
import java.util.List;

import tk.tekporacademy.betweener.DatabaseAccess;
import tk.tekporacademy.betweener.MainActivity;
import tk.tekporacademy.betweener.R;
import tk.tekporacademy.betweener.ui.home.HomeViewModel;

public class ForumFragment extends Fragment {
    RecyclerView recyclerView;
    LinearLayoutManager linearLayoutManager;
    private ForumViewModel forumViewModel;
    private long max;
    private String feeling;
    private String audance;
    private int luckynumber;
    private DatabaseReference databaseReference;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_forum, container, false);
        recyclerView = root.findViewById(R.id.recycle);
if (!new MainActivity().isNetworkAvailable(getContext())){
    Toast.makeText(getContext(),"YOU ARE OFFLINE SHOWING SAVED QUESTIONS...",Toast.LENGTH_LONG).show();
    DatabaseAccess databaseAccess = DatabaseAccess.getInstance(getContext());
    databaseAccess.open();
    List<String> saved = databaseAccess.getSavedQuestion();
    databaseAccess.close();
    databaseAccess.open();
    List<byte[]> blob = databaseAccess.getSavedBlobQuestion();
    databaseAccess.close();

if (blob.size() < 1){
    Toast.makeText(getContext(),"No Data Available",Toast.LENGTH_LONG).show();
}

    forumViewModel = new ForumViewModel(getContext(),audance,null, 0,blob,saved,null,null);
    linearLayoutManager = new LinearLayoutManager(requireContext());
    recyclerView.setLayoutManager(linearLayoutManager);
    recyclerView.setAdapter(forumViewModel);

}






        return root;
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
         luckynumber = (int) Math.round((Math.random()*2)+1);
        Fresco.initialize(
                getContext(),
                ImagePipelineConfig.newBuilder(getContext())
                        .setMemoryChunkType(MemoryChunkType.BUFFER_MEMORY)
                        .setImageTranscoderType(ImageTranscoderType.JAVA_TRANSCODER)
                        .experiment().setNativeCodeDisabled(true)
                        .build());

        if (new MainActivity().isNetworkAvailable(getContext())){
            Toast.makeText(getContext(),"LOADING...",Toast.LENGTH_LONG).show();
            Calendar c = Calendar.getInstance();
            int timeOfDay = c.get(Calendar.HOUR_OF_DAY);

            if (timeOfDay >= 6 && timeOfDay < 12) {
                feeling = "General";


                switch (luckynumber){
                    case 1:
                        audance = "Married";
                        break;
                    case 2:
                        audance = "Single";
                        break;
                    case 3:
                        audance = "General";
                        break;
                }


            } else if (timeOfDay >= 12 && timeOfDay < 18) {
                feeling = "Stress";

                switch (luckynumber){
                    case 1:
                        audance = "Married";
                        break;
                    case 2:
                        audance = "Single";
                        break;
                    case 3:
                        audance = "General";
                        break;
                }
            } else if (timeOfDay >= 18 && timeOfDay < 24) {
                feeling = "Love";


                switch (luckynumber){
                    case 1:
                        audance = "Married";
                        break;
                    case 2:
                        audance = "Single";
                        break;
                    case 3:
                        audance = "General";
                        break;
                }
            }else {
                feeling = "Love";


                switch (luckynumber){
                    case 1:
                        audance = "Married";
                        break;
                    case 2:
                        audance = "Single";
                        break;
                    case 3:
                        audance = "General";
                        break;
                }
            }
            databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/Question");
            databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    try {
                        if(snapshot.exists())
                            max = (snapshot.getChildrenCount());
                        forumViewModel = new ForumViewModel(getContext(),audance,feeling,max,null,null,null,null);
                        if (max < 1){
                            Toast.makeText(getContext(),"SORRY NO DATA AVAILABLE",Toast.LENGTH_LONG).show();
                        }
                        try {
                            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(requireContext());
                            recyclerView.setLayoutManager(linearLayoutManager);
                            recyclerView.setAdapter(forumViewModel);
                        }catch (IllegalStateException e){
                            e.getStackTrace();
                        }

                    }catch (NullPointerException e){
                        e.getStackTrace();
                    }

                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });

        }
    }
}