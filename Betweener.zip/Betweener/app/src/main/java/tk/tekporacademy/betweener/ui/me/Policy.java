package tk.tekporacademy.betweener.ui.me;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import tk.tekporacademy.betweener.R;

public class Policy extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.policy);
    }
}