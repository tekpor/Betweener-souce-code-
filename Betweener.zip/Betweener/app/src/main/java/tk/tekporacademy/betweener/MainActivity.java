package tk.tekporacademy.betweener;

import android.app.AlertDialog;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.sql.Date;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import tk.tekporacademy.betweener.ui.customize.Customize;
import tk.tekporacademy.betweener.ui.favorites.FragmentFavorite;
import tk.tekporacademy.betweener.ui.forum.ForumFragment;
import tk.tekporacademy.betweener.ui.home.HomeClickedValue;
import tk.tekporacademy.betweener.ui.home.HomeFragment;
import tk.tekporacademy.betweener.ui.me.MeFragment;
import tk.tekporacademy.betweener.ui.me.MeTag;

public class MainActivity extends AppCompatActivity {
 private    Uri urinotification;
 private  Button button;
   private DatabaseReference databaseReference;
    final String appVerion = "1";
    private int clicked;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        java.util.Date date = new java.util.Date();

       final String convert = String.valueOf(convert(date).getDate());


        databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/version");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!snapshot.child("version").getValue().toString().equals(appVerion)){
                    addNotification(snapshot.child("message").getValue().toString(),snapshot.child("subject").getValue().toString());
                    if (snapshot.child("date").getValue().toString().equals(convert)){
                        setContentView(R.layout.update);
                        button = findViewById(R.id.button);
                        button.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                String uri = String.format(Locale.ENGLISH, "https://tekporacademy.tk/about");
                                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
                                startActivity(intent);
                            }
                        });

                    }else {
                        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                        builder.setTitle(snapshot.child("title").getValue().toString())
                                .setMessage(snapshot.child("message").getValue().toString())
                                .setIcon(R.drawable.ic_baseline_update_24)
                                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        String uri = String.format(Locale.ENGLISH, "https://tekporacademy.tk/about");
                                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
                                        startActivity(intent);
                                    }
                                }).setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        });
                        AlertDialog dialog = builder.create();
                        dialog.show();

                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });




        //DatabaseAccess databaseAccess = DatabaseAccess.getInstance(MainActivity.this);
  //databaseAccess.open();
   // databaseAccess.setStore(MainActivity.this);
     // databaseAccess.close();


        BottomNavigationView navView = findViewById(R.id.nav_view);
        navView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment fragment = null;
                switch (item.getItemId()){
                    case R.id.navigation_home:
                        fragment = new HomeFragment();
                        clicked = 0;
                        break;
                    case R.id.navigation_customize:
                        fragment = new FragmentFavorite();
                        clicked = 0;
                        break;
                    case R.id.navigation_forum:
                        fragment = new ForumFragment();
                        clicked = 0;
                        break;
                    case R.id.navigation_me:
                        fragment = new MeFragment();
                        clicked = 0;
                        break;

                }
                if (fragment != null){
                    getSupportFragmentManager().beginTransaction().replace(R.id.nav_host_fragment,fragment).commit();
                }


                return true;
            }
        });

    }
    public boolean isNetworkAvailable( Context context) {
        ConnectivityManager connectivityManager
                = (ConnectivityManager)  context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    private void addNotification(String s, String t) {
        try {
            urinotification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone r = RingtoneManager.getRingtone(getApplicationContext(), urinotification);
            r.play();
        } catch (Exception e) {
            e.printStackTrace();
        }
        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(this)
                        .setSmallIcon(R.mipmap.ic_launcher)
                        .setContentTitle(t)
                        .setSound(urinotification)
                        .setContentText(s);

        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0, notificationIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        builder.setContentIntent(contentIntent);

        // Add as notification
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        manager.notify(0, builder.build());
    }
    private  java.sql.Date convert(java.util.Date uDate) {
        java.sql.Date sDate = new java.sql.Date(uDate.getTime());
        return sDate;
    }

    @Override
    public void onBackPressed() {
       if (clicked > 2){
           super.onBackPressed();
       }else {
           clicked+=1;
           if (clicked == 1){
               Toast.makeText(MainActivity.this,"CLICK AGAIN TO CLOSE THE APP",Toast.LENGTH_LONG).show();
           }else {
               Toast.makeText(MainActivity.this,"ARE YOU SURE YOU WANT CLOSE THIS APPLICATION",Toast.LENGTH_LONG).show();
           }

       }

    }
}