package tk.tekporacademy.betweener.objects;

public class Question {

    private String status;
    private String inspiration;
    private String handler;
    private String audiance;
    private String name;

    public Question(String userid, String inspiration, String handler, String audiance, String status) {
        this.inspiration = inspiration;
        this.handler = handler;
        this.audiance = audiance;
        this.name = userid;
        this.status = status;
    }

    public String getInspiration() {
        return inspiration;
    }

    public void setInspiration(String inspiration) {
        this.inspiration = inspiration;
    }

    public String getHandler() {
        return handler;
    }

    public void setHandler(String handler) {
        this.handler = handler;
    }

    public String getAudiance() {
        return audiance;
    }

    public void setAudiance(String audiance) {
        this.audiance = audiance;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }



}
