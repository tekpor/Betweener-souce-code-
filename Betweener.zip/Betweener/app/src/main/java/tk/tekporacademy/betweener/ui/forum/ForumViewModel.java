package tk.tekporacademy.betweener.ui.forum;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import tk.tekporacademy.betweener.DatabaseAccess;
import tk.tekporacademy.betweener.R;

public class ForumViewModel extends RecyclerView.Adapter<ForumViewModel.AddHolder> {
    public ForumViewModel(Context context, String people,String feeling, long nimber, List<byte[]> blob, List<String> list,String user,List<Integer> tag) {
        this.context = context;
        this.people = people;
        this.nimber = nimber;
        this.blob = blob;
        this.list = list;
        this.user = user;
        this.tag = tag;
        this.feeling = feeling;
    }

    private static Set<Integer> listed = new LinkedHashSet<Integer>();
    private static  List<Integer>set = new ArrayList<>();
    private StorageReference mStorageRef;
    private DatabaseReference databaseReference;
    Context context;
    String people;
    String user;
    List<Integer> tag;
    long nimber;
    List<byte[]> blob;
    List<String> list;

    String feeling;

    @NonNull
    @Override
    public ForumViewModel.AddHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.forum_recycle,parent,false);
        ForumViewModel.AddHolder holder = new ForumViewModel.AddHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull final ForumViewModel.AddHolder holder,final int position) {


        holder.cardView.setAnimation(AnimationUtils.loadAnimation(context,R.anim.splash));
        if (feeling == null){

            holder.container.setVisibility(View.VISIBLE);
            try {
                holder.id.setText(String.valueOf(position));
                Bitmap bitmap  = BitmapFactory.decodeByteArray(blob.get(position),0,blob.get(position).length);
                holder.qimage.setImageBitmap(bitmap);
                holder.cardView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(context, ForumComments.class);
                        intent.putExtra("id", list.get(position));
                        intent.putExtra("resource",1);
                        context.startActivity(intent);
                    }
                });

                holder.comments.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(context, ForumComments.class);
                        intent.putExtra("id", list.get(position));
                        intent.putExtra("resource",1);

                        context.startActivity(intent);
                    }
                });
            }catch (OutOfMemoryError e){
                e.getStackTrace();
            }
        }else {

            if (position == 0){
                rundom();
            };
if (tag != null){
    set = null;
    set = tag;
}
            databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/Question");
            databaseReference.child(String.valueOf(set.get(position))).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull final DataSnapshot snapshot) {
                    try {
                        if (tag !=null){
                            holder.container.setVisibility(View.VISIBLE);
                        }else if (user != null){
                            if (snapshot.child("username").getValue().toString().equals(user)){
                                holder.container.setVisibility(View.VISIBLE);
                            }
                        }else {
                            if (snapshot.child("people").getValue().toString().equals(people) && snapshot.child("status").getValue().toString().equals(feeling)){
                                holder.container.setVisibility(View.VISIBLE);
                            }
                        }

                    }catch (NullPointerException e){
                        e.getStackTrace();
                    }
                    try {

                        String  handler = snapshot.child("handler").getValue().toString();
                          final String id = snapshot.getKey();
                        final String   author = snapshot.child("username").getValue().toString();

                        holder.comments.setText(snapshot.child("comments").getValue().toString());
                      holder.like.setText(snapshot.child("view").getValue().toString());
                        holder.tag.setText(snapshot.child("tag").getValue().toString());
                        mStorageRef = FirebaseStorage.getInstance().getReference();
                        mStorageRef.child("question/"+handler+".png").getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                            @Override
                            public void onSuccess(final Uri uri) {
                                holder.qimage.setImageURI(uri);


                                holder.tag.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        DatabaseAccess databaseAccess = DatabaseAccess.getInstance(context);
                                        databaseAccess.open();
                                        databaseAccess.setTages(snapshot.getKey(),snapshot.child("username").getValue().toString());
                                        databaseAccess.close();
                                        databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/Question");
                                        databaseReference.child(String.valueOf(set.get(position))).child("tag").setValue(Integer.parseInt(snapshot.child("tag").getValue().toString())+1);
                                        Toast.makeText(context,"Tagged",Toast.LENGTH_LONG).show();
                                    }
                                });


                                holder.cardView.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        DatabaseAccess databaseAccess = DatabaseAccess.getInstance(context);
                                        databaseAccess.open();
                                        String getrestriction = databaseAccess.getrestriction();
                                        databaseAccess.close();

                                        if (getrestriction != null){

                                            if ( getrestriction.equals("1")){
                                                if (snapshot.child("people").getValue().toString() != "Married"){
                                                    Intent intent = new Intent(context, ForumComments.class);
                                                    intent.putExtra("postid",id);
                                                    intent.putExtra("like",snapshot.child("view").getValue().toString());
                                                    intent.putExtra("tag",snapshot.child("tag").getValue().toString());
                                                    intent.putExtra("resource",2);
                                                    intent.putExtra("uri",uri.toString());
                                                    intent.putExtra("username",author);
                                                    context.startActivity(intent);
                                                }else {
                                                    Toast.makeText(context,"You are in RESTRICTION MODE. Change that in 'ME'.",Toast.LENGTH_LONG).show();
                                                }
                                            } else {
                                                Intent intent = new Intent(context, ForumComments.class);
                                                intent.putExtra("postid",id);
                                                intent.putExtra("like",snapshot.child("view").getValue().toString());
                                                intent.putExtra("tag",snapshot.child("tag").getValue().toString());
                                                intent.putExtra("resource",2);
                                                intent.putExtra("uri",uri.toString());
                                                intent.putExtra("username",author);
                                                context.startActivity(intent);
                                            }


                                        }else {

                                            if (snapshot.child("status").getValue().toString() != "Love"){
                                                    Intent intent = new Intent(context, ForumComments.class);
                                                    intent.putExtra("postid",id);
                                                    intent.putExtra("like",snapshot.child("view").getValue().toString());
                                                intent.putExtra("tag",snapshot.child("tag").getValue().toString());
                                                    intent.putExtra("resource",2);
                                                    intent.putExtra("uri",uri.toString());
                                                    intent.putExtra("username",author);
                                                    context.startActivity(intent);

                                            }else {
                                                Toast.makeText(context,"You are in RESTRICTION MODE. Change that in 'ME'.",Toast.LENGTH_LONG).show();
                                            }

                                        }

                                    }
                                });



                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception exception) {
                                // Handle any errors
                            }
                        });

                    }catch (NullPointerException e){
                        e.getStackTrace();
                    }


                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });

        }

    }

    @Override
    public int getItemCount() {
        if (feeling == null){
            try {
                return blob.size();
            }catch (NullPointerException e){
                e.getStackTrace();
                return 0;
            }

        }else if (tag != null){
            return tag.size();
        }else {
            return (int) nimber;
        }

    }

    public class AddHolder extends RecyclerView.ViewHolder {
        CardView cardView;
        TextView comments;
        TextView id,tag;
        TextView like;
        SimpleDraweeView qimage;
        LinearLayout container;

        public AddHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.card);
            container = itemView.findViewById(R.id.container);
            qimage = itemView.findViewById(R.id.qimage);
            comments = itemView.findViewById(R.id.comments);
            id = itemView.findViewById(R.id.id);
            tag = itemView.findViewById(R.id.tag);
            like = itemView.findViewById(R.id.like);
        }
    }
    public  void rundom(){
        Random randNum = new Random();

        while (listed.size() < (int) nimber) {
            listed.add(randNum.nextInt((int) nimber)+1);
        }
        set.addAll(listed);
    }

}