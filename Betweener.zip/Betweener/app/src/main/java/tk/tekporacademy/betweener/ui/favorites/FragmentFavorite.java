package tk.tekporacademy.betweener.ui.favorites;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Toast;
import android.widget.ViewFlipper;

import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.imagepipeline.core.ImagePipelineConfig;
import com.facebook.imagepipeline.core.ImageTranscoderType;
import com.facebook.imagepipeline.core.MemoryChunkType;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

import pl.droidsonroids.gif.GifImageView;
import tk.tekporacademy.betweener.MainActivity;
import tk.tekporacademy.betweener.R;
import tk.tekporacademy.betweener.ui.forum.ForumViewModel;
import tk.tekporacademy.betweener.ui.home.HomeViewModel;

public class FragmentFavorite extends Fragment {
    private  RecyclerView recyclerView;
    private RelativeLayout relativeLayout;
    private FavouriteViewModel favouriteViewModel;
    private ViewFlipper viewFlipper;
    private  DatabaseReference databaseReference;
    private long max;
    private long current = 0;
    private long getCurrent = 20;
    private GifImageView loading;
    private String feeling;
    private ImageView more;
    private  int luckynumber;
    private String audance;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View inflate = inflater.inflate(R.layout.fragment_favorites, container, false);
        viewFlipper = inflate.findViewById(R.id.viewFlipper);
        relativeLayout = inflate.findViewById(R.id.homeClick);
        loading = inflate.findViewById(R.id.loading);
        more = inflate.findViewById(R.id.more);
        recyclerView = inflate.findViewById(R.id.recycle);
        more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (max< pageNumber()){
                    more.setVisibility(View.GONE);
                }else {
                    current +=10;
                    favouriteViewModel.setMaxed(pageNumber());

                    Random randNum = new Random();
                    Set<Integer> list = new LinkedHashSet<Integer>();
                    List<Integer> set = new ArrayList<>();
                    while (list.size() < (int) pageNumber()) {
                        list.add(randNum.nextInt((int) pageNumber())+1);
                    }
                    set.addAll(list);
                    favouriteViewModel.setSet(set);


                    favouriteViewModel.notifyDataSetChanged();
                }
            }
        });
        return inflate;
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        luckynumber = (int) Math.round((Math.random()*2)+1);
        Fresco.initialize(
                getContext(),
                ImagePipelineConfig.newBuilder(getContext())
                        .setMemoryChunkType(MemoryChunkType.BUFFER_MEMORY)
                        .setImageTranscoderType(ImageTranscoderType.JAVA_TRANSCODER)
                        .experiment().setNativeCodeDisabled(true)
                        .build());




        if (new MainActivity().isNetworkAvailable(getContext())){
            Calendar c = Calendar.getInstance();
            int timeOfDay = c.get(Calendar.HOUR_OF_DAY);

            if (timeOfDay >= 0 && timeOfDay < 9) {
                feeling = "Morning";


                switch (luckynumber){
                    case 1:
                        audance = "Family";
                        break;
                    case 2:
                        audance = "Partner";
                        break;
                    case 3:
                        audance = "Friends";
                        break;
                }


            } else if (timeOfDay >= 9 && timeOfDay < 16) {
                feeling = "Afternoon";


                switch (luckynumber){
                    case 1:
                        audance = "Family";
                        break;
                    case 2:
                        audance = "Partner";
                        break;
                    case 3:
                        audance = "Friends";
                        break;
                }
            } else if (timeOfDay >= 16 && timeOfDay < 24) {
                feeling = "Evening";


                switch (luckynumber){
                    case 1:
                        audance = "Family";
                        break;
                    case 2:
                        audance = "Partner";
                        break;
                    case 3:
                        audance = "Friends";
                        break;
                }
            }
            databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/Save/Fun");
            databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    try {
                        if(snapshot.exists())
                            max = (snapshot.getChildrenCount());
                        favouriteViewModel = new FavouriteViewModel(getContext(),null,null,pageNumber(),audance);
                        try {
                            if (max < 1){
                                Toast.makeText(getContext(),"SORRY NO DATA AVAILABLE",Toast.LENGTH_LONG).show();
                            }
                        }catch (NullPointerException e){
                            e.getStackTrace();
                        }
                        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(requireContext());
                        recyclerView.setHasFixedSize(true);
                        recyclerView.setLayoutManager(linearLayoutManager);
                        recyclerView.setAdapter(favouriteViewModel);
                        loading.setVisibility(View.GONE);
                        if (getCurrent > max){
                            more.setVisibility(View.GONE);
                        }else {
                            more.setVisibility(View.VISIBLE);
                        }
                    }catch (IllegalStateException e){
                        e.getStackTrace();
                    }

                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }
    }

    private int pageNumber(){
        if (getCurrent > max){
            more.setVisibility(View.GONE);
            return (int) max;
        }else {
            more.setVisibility(View.VISIBLE);
            if (getCurrent+current > max){
                if (getCurrent+current < max+5){
                    more.setVisibility(View.GONE);
                    return (int) max;
                }else {
                    return (int) (getCurrent+current-3);
                }
            }else {
                return (int) (getCurrent+current);
            }
        }


    }
}