package tk.tekporacademy.betweener.ui.home;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import tk.tekporacademy.betweener.R;

public class ProfileView extends AppCompatActivity {
    private  RecyclerView recyclerView;
   private String name ="null";
    ProfileModel profileModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_view);
        recyclerView = findViewById(R.id.profileViewRecy);
        Intent intent = getIntent();
         name = intent.getStringExtra("name");
        profileModel = new ProfileModel(this);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(profileModel);
    }
}