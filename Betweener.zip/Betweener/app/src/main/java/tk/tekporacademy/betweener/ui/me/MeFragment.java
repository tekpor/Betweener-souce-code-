package tk.tekporacademy.betweener.ui.me;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.List;
import java.util.Locale;

import de.hdodenhof.circleimageview.CircleImageView;
import tk.tekporacademy.betweener.DatabaseAccess;
import tk.tekporacademy.betweener.MainActivity;
import tk.tekporacademy.betweener.R;
import tk.tekporacademy.betweener.ui.customize.Customize;

public class MeFragment extends androidx.fragment.app.Fragment {
    private TextView save,question,tag,profile,site,signout,policy,like,share,about;
    CircleImageView profile_image;
    private  int SELECT_FILE =0;
    private EditText code;
    private Switch aSwitch,getaSwitch;
    private DatabaseReference databaseReference;
    private StorageReference mStorageRef;
    @SuppressLint("ResourceAsColor")
    @RequiresApi(api = Build.VERSION_CODES.Q)
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_me, container, false);
        signout = root.findViewById(R.id.signout);
        save = root.findViewById(R.id.save);
        like = root.findViewById(R.id.like);
        share = root.findViewById(R.id.share);
        about = root.findViewById(R.id.about);
        aSwitch = root.findViewById(R.id.switchNotification);
        getaSwitch = root.findViewById(R.id.switchRestriction);
        policy = root.findViewById(R.id.policy);
        site = root.findViewById(R.id.site);
        question = root.findViewById(R.id.quote);
        tag = root.findViewById(R.id.tag);
        code = root.findViewById(R.id.code);

        like.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String uri = String.format(Locale.ENGLISH, "https://facebook.com/tekporaca");
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
                startActivity(intent);
            }
        });

        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String uri = String.format(Locale.ENGLISH, "https://tekporacademy.tk/about");
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
                startActivity(intent);
            }
        });

        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent shareIntent =   new Intent(android.content.Intent.ACTION_SEND);
                shareIntent.setType("text/plain");
                shareIntent.putExtra(Intent.EXTRA_SUBJECT,"Betweener");
                String app_url = "BETWEENER, connecting you to your love ones. Get it at google play https://play.google.com/store/apps/details?id=tk.tekporacademy.betweener";
                shareIntent.putExtra(android.content.Intent.EXTRA_TEXT,app_url);
                startActivity(Intent.createChooser(shareIntent, "Share via"));
            }
        });

        policy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(),Policy.class);
                getContext().startActivity(intent);
            }
        });

        site.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(),AskQuestion.class);
                getContext().startActivity(intent);
            }
        });


        signout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                    builder.setTitle("SIGN OUT")
                            .setMessage("ARE YOU SURE YOU WANT TO SIGN OUT?")
                            .setIcon(R.drawable.ic_baseline_warning_24)
                            .setNegativeButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    DatabaseAccess databaseAccess = DatabaseAccess.getInstance(getContext());
                                    databaseAccess.open();
                                    databaseAccess.signout();
                                    databaseAccess.close();
Intent intent = new Intent(getContext(), MainActivity.class);
getActivity().startActivity(intent);
                                }
                            }).setPositiveButton(android.R.string.no, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {

                        }
                    });
                    AlertDialog dialog = builder.create();
                    dialog.show();

            }
        });

        profile = root.findViewById(R.id.profile);
        profile_image = root.findViewById(R.id.profile_image);

        DatabaseAccess databaseAccess = DatabaseAccess.getInstance(getContext());
        databaseAccess.open();
        List<String> uerName = databaseAccess.getUerName();
        databaseAccess.close();

        databaseAccess.open();
        List<byte[]> userBlob = databaseAccess.getUserBlob();
        databaseAccess.close();

        databaseAccess.open();
        String coded = databaseAccess.getconfirm();
        databaseAccess.close();
try {

    if (!coded.isEmpty()){
        code.setVisibility(View.GONE);
    }
}catch (NullPointerException e){
    e.getStackTrace();
}




        code.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String s = code.getText().toString();
                if (s.length() == 4){
                    ///
                    DatabaseAccess databaseAccess = DatabaseAccess.getInstance(getContext());
                    databaseAccess.open();
                    String coded = databaseAccess.getCode();
                    databaseAccess.close();



                    if (coded!=null){

                        if (coded.equals(s)){
                            code.setVisibility(View.GONE);
                            databaseAccess.open();
                            databaseAccess.setCode(s);
                            databaseAccess.close();
                        }
                    }else {
                        Toast.makeText(getContext(),"SIGN IN FIRST",Toast.LENGTH_LONG).show();
                    }

                    code.setText("");
                    ///
                }
            }
            @Override
            public void afterTextChanged(Editable editable) {
            }
        });


        if (!uerName.isEmpty()){

            databaseAccess.open();
            String getrestriction = databaseAccess.getrestriction();
            databaseAccess.close();

            if (getrestriction != null){
                if (getrestriction.equals("1")){
                    getaSwitch.setChecked(true);
                }else{
                    getaSwitch.setChecked(false);
                }
            }



            getaSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                        DatabaseAccess databaseAccess = DatabaseAccess.getInstance(getContext());
                        databaseAccess.open();
                        databaseAccess.restriction(b);
                        databaseAccess.close();

                }
            });
            profile.setText(uerName.get(0));
            profile.setTextColor(getResources().getColor(R.color.blue));

            mStorageRef = FirebaseStorage.getInstance().getReference();
            mStorageRef.child("profile/"+profile.getText().toString()+".png").getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                @Override
                public void onSuccess(Uri uri) {
                    if (uri!=null){
                        Picasso.get().load(uri).placeholder(R.drawable.ic_baseline_perm_identity_24).into(profile_image);
                    }
                }
            });
        }else {
            signout.setVisibility(View.GONE);
            getaSwitch.setChecked(true);
            getaSwitch.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    getaSwitch.setChecked(true);
                    Toast.makeText(getContext(),"SIGN IN FIRST",Toast.LENGTH_LONG).show();
                }
            });
        }

        if (userBlob != null){

            try {
                try {
                    Bitmap bitmap  = BitmapFactory.decodeByteArray(userBlob.get(0),0,userBlob.get(0).length);
                    profile_image.setImageBitmap(bitmap);
                }catch (IndexOutOfBoundsException e){
                    e.getStackTrace();
                }

            }catch (NullPointerException e){
                e.getStackTrace();
            }

        }

        profile_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!profile.getText().toString().equals("SIGN UP")){
                    Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    intent.setType("image/*");
                    startActivityForResult(Intent.createChooser(intent,"Select Image (Size < 3MB)"),SELECT_FILE);
                }
            }
        });


        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getContext(),"Loading",Toast.LENGTH_LONG).show();
                Intent intent = new Intent(getContext(),MeSave.class);
                getContext().startActivity(intent);
            }
        });

        question.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), Customize.class);
                getContext().startActivity(intent);
            }
        });


        tag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(),MeTag.class);
                getContext().startActivity(intent);
            }
        });

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (profile.getText().toString().equals("SIGN UP")){
Intent intent = new Intent(getContext(),Register.class);
getContext().startActivity(intent);
                }
            }
        });
        return root;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        DatabaseAccess databaseAccess = DatabaseAccess.getInstance(getContext());
        try {
            Uri uri = null;
            if (requestCode == SELECT_FILE){
                try {
                    uri = data.getData();
                    profile_image.setImageURI(uri);
                    Bitmap bitmap = getBitmap(profile_image);
                    databaseAccess.open();
                    databaseAccess.setProfile(bitmap,getContext());
                    databaseAccess.close();
                }catch (RuntimeException e){
                    Toast.makeText(getContext(),e.getMessage(),Toast.LENGTH_SHORT).show();
                }
            }
        }catch (OutOfMemoryError e){
            final PackageManager pm = getActivity().getPackageManager();
            final Intent intent = pm.getLaunchIntentForPackage(getActivity().getPackageName());
            getActivity().finishAffinity();
            startActivity(intent);
            System.exit(0);
        }

    }

    private Bitmap getBitmap(View view){
        Bitmap bitmap =null;
        Canvas canvas = null;
        Drawable drawable = null;
        try {
            bitmap = Bitmap.createBitmap(view.getWidth(),view.getHeight(),Bitmap.Config.ARGB_8888);
            canvas = new Canvas(bitmap);
            drawable = view.getBackground();
        }catch (IllegalArgumentException e){
            Toast.makeText(getContext(),e.getMessage(),Toast.LENGTH_SHORT).show();
        }

        if (drawable != null){
            drawable.draw(canvas);
        }else {
            try {
                canvas.drawColor(getResources().getColor(R.color.whitetrans));
            }catch (NullPointerException e){
                Toast.makeText(getContext(),e.getMessage(),Toast.LENGTH_SHORT).show();
            }

        }

        try {
            view.draw(canvas);
        }catch (NullPointerException e){
            Toast.makeText(getContext(),e.getMessage(),Toast.LENGTH_SHORT).show();
        }
        return bitmap;
    }

    @Override
    public void onResume() {
        super.onResume();
        DatabaseAccess databaseAccess = DatabaseAccess.getInstance(getContext());
        databaseAccess.open();
        List<String> uerName = databaseAccess.getUerName();
        databaseAccess.close();
        databaseAccess.open();
        List<byte[]> userBlob = databaseAccess.getUserBlob();
        databaseAccess.close();
        if (!uerName.isEmpty()){
            profile.setText(uerName.get(0));
            profile.setTextColor(getResources().getColor(R.color.blue));
        }
        if (userBlob != null){
            try {
                try {
                    Bitmap bitmap  = BitmapFactory.decodeByteArray(userBlob.get(0),0,userBlob.get(0).length);
                    profile_image.setImageBitmap(bitmap);
                }catch (IndexOutOfBoundsException e){
                    e.getStackTrace();
                }
            }catch (NullPointerException e){
                e.getStackTrace();
            }

        }
    }
}