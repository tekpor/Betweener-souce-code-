package tk.tekporacademy.betweener.ui.home;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import tk.tekporacademy.betweener.R;

public class ProfileModel extends RecyclerView.Adapter<ProfileModel.holder> {
    public ProfileModel(Context context) {
        this.context = context;
    }

    Context context;
    @NonNull
    @Override
    public holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.home_recycle,parent,false);
        holder holder = new holder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull final holder holder, int position) {
holder.share.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        share(holder.cardView);
    }
});
    }

    @Override
    public int getItemCount() {
        return 10;
    }

    public class holder extends RecyclerView.ViewHolder {
        CardView cardView;
        TextView share;
        TextView save;
        TextView id;
        TextView like;
        ImageView qimage;
        public holder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.card);
            share = itemView.findViewById(R.id.share);
            save = itemView.findViewById(R.id.save);
            like = itemView.findViewById(R.id.like);
            qimage = itemView.findViewById(R.id.qimage);
            id = itemView.findViewById(R.id.id);
        }
    }
    public void share(View view) {
        Bitmap b = getBitmap(view);
        String filename = Math.random()+"betweener.png";
        try {
            File file = new File(context.getExternalCacheDir(),filename);
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            b.compress(Bitmap.CompressFormat.PNG,100,fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
            file.setReadable(true,false);
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(file));
            intent.setType("image/png");
            context.startActivity(Intent.createChooser(intent,"Share via"));

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private Bitmap getBitmap(View view){
        Bitmap bitmap = Bitmap.createBitmap(view.getWidth(),view.getHeight(),Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Drawable drawable = view.getBackground();
        if (drawable != null){
            drawable.draw(canvas);
        }else {
            canvas.drawColor(context.getResources().getColor(R.color.whitetrans));
        }
        view.draw(canvas);
        return bitmap;
    }
}
