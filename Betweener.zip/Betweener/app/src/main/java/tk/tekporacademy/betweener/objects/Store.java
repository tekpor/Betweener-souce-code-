package tk.tekporacademy.betweener.objects;

public class Store {
    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    String link;

    public Store(String link) {
        this.link = link;
    }
}
