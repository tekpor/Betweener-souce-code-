package tk.tekporacademy.betweener.objects;

public class Save {



    public String getAudiance() {
        return audiance;
    }

    public void setAudiance(String audiance) {
        this.audiance = audiance;
    }

    private String userid;
    private String inspiration;
    private String handler;
    private String audiance;
    private String name;
    private String share;
    private String like;
    private String view;
    private String save;

    public Save( String name,String userid, String inspiration, String handler, String audiance, String share, String like, String view, String save) {
        this.userid = userid;
        this.inspiration = inspiration;
        this.handler = handler;
        this.audiance = audiance;
        this.name = name;
        this.share = share;
        this.like = like;
        this.view = view;
        this.save = save;
    }






    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getInspiration() {
        return inspiration;
    }

    public void setInspiration(String inspiration) {
        this.inspiration = inspiration;
    }

    public String getHandler() {
        return handler;
    }

    public void setHandler(String handler) {
        this.handler = handler;
    }

}
