package tk.tekporacademy.betweener.ui.forum;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;

import tk.tekporacademy.betweener.R;

public class ForumCommentViewModel extends RecyclerView.Adapter<ForumCommentViewModel.AddHolder> {

    List<String> list;

    public ForumCommentViewModel(List<String> list, long max,String postid,  Context context) {
        this.list = list;
        this.max = max;
        this.context = context;
        this.postid = postid;
    }
  private   int imcreament;
    long max;
    Context context;
    String postid;
    private DatabaseReference databaseReference;


    @NonNull
    @Override
    public ForumCommentViewModel.AddHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.forum_recycle_comments,parent,false);
        ForumCommentViewModel.AddHolder holder = new ForumCommentViewModel.AddHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull final ForumCommentViewModel.AddHolder holder, final int position) {
        holder.container.setAnimation(AnimationUtils.loadAnimation(context,R.anim.splash));
        if (max ==  0){
try {

    holder.comments.setText(list.get(imcreament));
    holder.replyComment.setText(list.get(imcreament+1));

}catch (IndexOutOfBoundsException e){
    e.getStackTrace();
}
            imcreament+=2;

        }else {
            databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/comment/"+postid);
            databaseReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {

                    databaseReference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://betweener-707a2.firebaseio.com/comment/"+postid+"/".concat(String.valueOf(max-position)));
                    databaseReference.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            try {
                                holder.comments.setText(snapshot.child("message").getValue().toString());
                                holder.replyComment.setText(snapshot.child("username").getValue().toString());
                            }catch (NullPointerException e){
                                e.getStackTrace();
                            }

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });

        }



    }

    @Override
    public int getItemCount() {
        int number = 0;
        try {
            if (max ==  0){

                if (list.size() > 0){
                    number = list.size()/2;
                }
            }else {
                number = (int) max;
            }
        }catch (NullPointerException e){
            e.getStackTrace();
        }

        return number;
    }

    public class AddHolder extends RecyclerView.ViewHolder {

        TextView replyComment;
        TextView comments;
        RelativeLayout container;
        public AddHolder(@NonNull View itemView) {
            super(itemView);
            replyComment = itemView.findViewById(R.id.replyComment);
            container = itemView.findViewById(R.id.container);
            comments = itemView.findViewById(R.id.comments);
        }
    }
}